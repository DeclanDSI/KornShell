﻿****Permission*********************************
id: Display user identity.
passwd: Change a user’s password.
su: Run a shell as another user.           sudo: Execute a command as another user.
umask: Set the default file permissions.
chmod: file’s mode.   chown: file’s owner.   chgrp: file’s group ownership.

/etc/passwd :  account info    /etc/shadow  : passwd info   /etc/group   : group info

---------------------------------------------
[me@linuxbox ~]$ ls -l foo.txt
-rwxrw-r-- 1 me me 0 2012-03-06 14:52 foo.txt
rwx owner permission
rw- group permission
r-- world permission

Lrwxrwxrwx : all symbolic link with “dummy” permissions. real permissions @the actual file.

chmod Symbolic Notation===============================
Octal 			Binary 		File Mode
0 				000 		---
1 				001 		--x
2 				010 		-w-
3 				011 		-wx
4 				100 		r--
5 				101 		r-x
6 				110 		rw-
7 				111 		rwx

symbolic representation:
u  : user (file or directory owner) 
g  : Group owner.
o  : others 
a  : all (combination of u, g, and o)
Notation 		Meaning
u+x 			Add execute permission for the owner.
u-x 			Remove execute permission from the owner.
+x 				Same as a+x.			#all
o-rw 			Remove the read and write permissions from anyone besides the owner and group owner.			
go=rw 			Set the group owner and anyone besides the owner to have read and write permission. 
u+x,go=rx 		Add execute permission for the owner and set the permissions for the group and others to read and execute.
		
=umask: Set Default Permissions=====
rm -f foo.txt
umask; > foo.txt; ls -l foo.txt  # 0002
-rw-rw-r-- 1 me me 0 2012-03-06 14:53 foo.txt

=unset permission attribute============
Original file mode   ---  rw-  rw-  rw-
Mask				 000  000  000  010
Result               ---  rw-  rw-  r--

# When you’re done, remember to clean up:
$ rm foo.txt; umask 0002

/etc/sudoers

=su -c 'command'==========
enclose the command in quotes, to prevent expansion in original shell, but rather in the new shell

$ su -c 'ls -l /root/*'
Password:
-rw------- 1 root root 754 2011-08-11 03:19 /root/anaconda-ks.cfg

=su vs sudo=========
sudo: same shell, no password, commands do not need to be quoted 
su :  new shell, require password , command to be quoted.

$ sudo -l  # privileges by sudo, use the -l option to list them
User me may run the following commands on this host:
(ALL) ALL

=chown: Change File Owner and Group=============
Argument 				Results
bob 					Changes  to user bob.
bob:users 				Changes  to user bob, changes file group owner to group users.
:admins 				Changes to group admins. file owner is unchanged.
bob: 					Change file owner to user bob , group owner to the login group of user bob.
	
sudo cp myfile.txt ~tony; sudo ls -l ~tony/myfile.txt           #-rw-r--r-- 1 root root 8031 2012-03-20 14:30 /home/tony/myfile.txt
sudo chown tony: ~tony/myfile.txt ; sudo ls -l ~tony/myfile.txt #-rw-r--r-- 1 tony tony 8031 2012-03-20 14:30 /home/tony/myfile.txt

=chgrp: Change Group Ownership===================

Bill creates: grp: Music , grp usrs:  William Shotts   Karen Shotts
sudo mkdir /usr/local/share/Music; ls -ld /usr/local/share/Music   #drwxr-xr-x 2 root root 4096 2012-03-21 18:05 /usr/local/share/Music
sudo chown :music /usr/local/share/Music; sudo chmod 775 /usr/local/share/Music; ls -ld /usr/local/share/Music
drwxrwxr-x 2 root music 4096 2012-03-21 18:05 /usr/local/share/Music

$ > /usr/local/share/Music/test_file; ls -l /usr/local/share/Music
-rw-r--r-- 1 bill bill 0 2012-03-24 20:03 test_file

- each file, directory created, set to the primary group of the user -> set the setgid bit on the directory
- change the umask used by bill and karen to 0002 instead.

$ sudo chmod g+s /usr/local/share/Music; ls -ld /usr/local/share/Music
drwxrwsr-x 2 root music 4096 2012-03-24 20:03 /usr/local/share/Music
$ umask 0002; rm /usr/local/share/Music/test_file; > /usr/local/share/Music/test_file
$ mkdir /usr/local/share/Music/test_dir ;  ls -l /usr/local/share/Music
drwxrwsr-x 2 bill music 4096 2012-03-24 20:24 test_dir
-rw-rw-r-- 1 bill music 0 2012-03-24 20:22 test_file

## Changing password
[me@linuxbox ~]$ passwd [user]
(current) UNIX password:
New UNIX password:

***redirection***************
Standard Input, Output, and Error=======
-both stdout & stderr are linked to the screen, not saved into a disk file.
-by default, stdin attached to the keyboard, stdout to screen, but I/O redirection can change it.

Redirecting Standard Output========
ls -l /usr/bin > ls-output.txt
ls -l /usr/bin >> ls-output.txt

file descriptor===========
standard input:0, output:1, error:2
ls -l /bin/usr 2>  ls-error.txt        # stderr to the file
ls -l /bin/usr 2> /dev/null            # suppress stderr, dispose unwanted output.
ls -l /bin/usr >   ls-output.txt 2>&1  # stdout & stderr to file 
ls -l /bin/usr &>  ls-output.txt       # stdout & stderr to file,  more advanced bash
ls -l /bin/usr 2>&1 ls-output.txt      # stderr to file and screen


Redirecting Standard Input=========
cat > cat.txt
The quick brown fox jumped over the lazy dog.
CTRL-D   # end-of-file (EOF) on standard input

Pipelines======================
command1 | command2  # read data from stdin and send to stdout
ls -l /usr/bin | less

Filters=sort/uniq/grep===================
ls /bin /usr/bin | sort | less
ls /bin /usr/bin | sort | uniq | less
ls /bin /usr/bin | sort | uniq -d | less  # list of duplicates

wc ls-output.txt # 7902 64566 503634 ls-output.txt    #line num, words, and bytes

ls /bin /usr/bin | sort | uniq | wc -l   #number of line   # 2728
ls /bin /usr/bin | sort | uniq | grep zip
bunzip2
bzip2
gunzip
...
zipsplit

grep -v # grep only lines that do not match the pattern

head/tail/tee======================
head/tail command prints the first/last 5 lines of a file

head -n 5 ls-output.txt
tail -n 5 ls-output.txt

tail -f /var/log/messages  #security contained msg
Feb 8 13:40:05 twin4 dhclient: DHCPACK from 192.168.1.1
Feb 8 13:40:05 twin4 dhclient: bound to 192.168.1.4 -- renewal in 1652 seconds.

ls /usr/bin | tee ls.txt | grep zip  # tee: Read from, Stdin & stdout, to screen & Files 
bunzip2
bzip2
gunzip

*************vi*******************************
Moving the Cursor Around----
H left ,J down, K up, L right

Line Opening Keys---------
o The line below, O The line above 

Deleting Text-------
3x The current character and the next two characters
dd The current line
5dd The current line and the next four lines
d$   From cursor location to the end of the current line
d20G From current line to the 20th line 

Cutting, Copying, and Pasting Text-------
yy  The current line
5yy The current line and the next four lines
y$   From current cursor location to the end of the current line
y20G From current line to the 20th line of the file

Joining Lines---------------
J   join lines together

Global Search and Replace==================
:%s/line/Line/gc  : specify a substitution command with user confirmation.

Item 		Meaning
: 			The colon character starts an ex command.
%			from the first line to the last line. specified 1,5 or 1,$  By default, on the current line.		
s			substitution (search and replace).
/Line/line/ search pattern and the replacement text.
g 			global

Replace Confirmation keys-----------------
n Skip this instance of the pattern.
a Perform the substitution on this and all
q or ESC Quit substituting.
l Perform this substitution and then quit. Short for last

Editing Multiple Files=================
ls -l /usr/bin > ls-output.txt	; vi foo.txt ls-output.txt

vi will start up,  first file on the screen
Switching Between Files-----------
:n  To switch from one file to the next, use this ex command
:N  To move back to the previous file

Inserting an Entire File into Another====
$ vi ls-output.txt
:r foo.txt  : Move the cursor to the line 

***Using History**********
~/.bash_history

Searching History========================
history | less
history | grep /usr/bin
88 ls -l /usr/bin > ls-output.txt

History expansion===================
$ !88  #88th line in the history list

Reverse History search======================
CTRL-R:  /usr/bin  ==>  (reverse-i-search)`/usr/bin`: ls -l /usr/bin > ls-output.txt 
CTRL-J ==>   ls -l /usr/bin > ls-output.txt

History Expansion Commands=======================
Sequence 						Action
!! 								Repeat the last command. 
!number 						Repeat the history number.
!string 						last history starting with string.
!?string 						last history containing string.

SCRIPT============================================
script: record an entire shell session and store it in a file.
basic syntax of the command is script [file]

****textprocessing************
 cat > foo.txt
The quick brown fox
jumped over the lazy dog.

 cat -A foo.txt
^IThe quick brown fox jumped over the lazy dog. $

cat -ns foo.txt  #-s : suppress the output of multiple blank lines
1 The quick brown fox
2
3 jumped over the lazy dog.

sort > foo.txt   #CTRL+D EOF = > a b c
c
b
a

sort file1.txt file2.txt file3.txt > final_sorted_list.txt

du -s /usr/share/* | sort -nr | head  #10 largest consumers of space
509940 /usr/share/locale-langpack
242660 /usr/share/doc
197560 /usr/share/fonts
...

ls -l /usr/bin | head
total 152948
-rwxr-xr-x 1 root root 34824 2012-04-04 02:42 
-rwxr-xr-x 1 root root 101556 2011-11-27 06:08 a2p
-rwxr-xr-x 1 root root 13036 2012-02-27 08:22 aconnect

ls -l /usr/bin | sort -nr -k 5 | head
-rwxr-xr-x 1 root root 8234216 2012-04-07 17:42 inkscape
-rwxr-xr-x 1 root root 8222692 2012-04-07 17:42 inkview
-rwxr-xr-x 1 root root 3746508 2012-03-07 23:45 gimp-2.4

$ head /etc/passwd
$ sort -t ':' -k 7 /etc/passwd | head
me:x:1001:1001:Myself,,,:/home/me:/bin/bash
root:x:0:0:root:/root:/bin/bash
dhcp:x:101:102::/nonexistent:/bin/false
gdm:x:106:114:Gnome Display Manager:/var/lib/gdm:/bin/false
...
uniq—Report or Omit Repeated Lines=====================
cat > foo.txt
a
b
c
a
b
c
uniq foo.txt
sort foo.txt | uniq
sort foo.txt | uniq -c  # report the number of duplicates
2 a
2 b
2 c

Slicing and Dicing==========================
---distros---------
SUSE 10.2 12/07/2006
Fedora 10 11/25/2008
SUSE 11.0 06/19/2008
Ubuntu 8.04 04/24/2008
Fedora 8 11/08/2007
SUSE 10.3 10/04/2007
Ubuntu 6.10 10/26/2006
.---------------------
cat -A distros.txt
SUSE^I10.2^I12/07/2006$
Fedora^I10^I11/25/2008$

cut -d ' ' -f3 distros | cut -c 7-10
2006
2008
2008

cut -d ':' -f1 /etc/passwd | head  # root/n  daemon/n ...

paste—Merge Lines of Files=====================
k (key sort) , b (ignore leading blanks),  n (numeric sort), r (reverse sort)
-k 3.7 : sorting begins at the seventh character within the third field, the year:
sort -k 3.7nbr -k 3.1nbr -k 3.4nbr distros > distros-bydate
Fedora 10 11/25/2008
Ubuntu 8.10 10/30/2008
SUSE 11.0 06/19/2008
...
cut -d ' ' -f 1,2 distros-bydate > distros-versions ; head distros-versions
Fedora 10
Ubuntu 8.10
SUSE 11.0
Fedora 9
...
cut -d ' ' -f3 distros-bydate> distros-dates; head distros-dates
11/25/2008
10/30/2008
06/19/2008
...
cut -f 1,1 distros-bydate > distros-names; head distros-names
Fedora 10 11/25/2008
SUSE 11.0 06/19/2008
Ubuntu 8.04 04/24/2008
...
paste distros-dates distros-names > distros-key-names; head distros-key-names
11/25/2008 Fedora
10/30/2008 Ubuntu
06/19/2008 SUSE
...

cut -f 2,2 distros-bydate> distros-vernums; head distros-vernums
paste distros-dates distros-vernums> distros-key-vernums;  head distros-key-vernums
11/25/2008 10
10/30/2008 8.10
06/19/2008 11.0
...
join distros-key-names distros-key-vernums | head # shared key (“release date”) for join to work 
11/25/2008 Fedora 10
10/30/2008 Ubuntu 8.10
06/19/2008 SUSE 11.0
...

comm & diff=====================
cat > file1.txt # a/n b /n c/n d/n
cat > file2.txt #     b/n c/n d/n e
comm file1.txt file2.txt  #Comparing Text
a
		b
		c
		d
	e
diff -c file1.txt file2.txt
***************
*** 1,4 ****
- a
b
c
d
--- 1,4 ----
b
c
d
+ e
patch (Apply a diff to an Original)=====================
diff -Naur file1.txt file2.txt > patchfile.txt  ; patch < patchfile.txt ; cat file1.txt
b
c
d
e
Editing on the Fly=========================================
tr: Transliterate or Delete Characters
echo "lowercase letters" | tr a-z A-Z   # LOWERCASE LETTERS
echo "lowercase letters" | tr [:lower:] A # AAAAAAAAA AAAAAAA
echo "aaabbbccc" | tr -s ab  #-s,“squeeze” (delete) repeat ==> abccc

sed — Stream Editor for Filtering and Transforming Text==============
echo "front" | sed 's/front/back/'  # back
echo "front" | sed 's_front_back_'  #back
echo "front" | sed '1s/front/back/' # back   #address 1 -> substitution on the first line.
echo "front" | sed '2s/front/back/' # front #no second line
echo "aaabbbccc" | sed 's/b/B/'  # aaaBbbccc
echo "aaabbbccc" | sed 's/b/B/g' # aaaBBBccc

sed -n '1,5p' distros   # -n (the no autoprint option), line 1 and continuing to line 5, -print
SUSE 10.2 12/07/2006
Fedora 10 11/25/2008
SUSE 11.0 06/19/2008

sed -n '/SUSE/p' distros #regex ,grep SUSE
SUSE 10.2 12/07/2006
SUSE 11.0 06/19/2008
SUSE 10.3 10/04/2007

sed -n '/SUSE/!p' distros #negate
Fedora 10 11/25/2008
Ubuntu 8.04 04/24/2008
Fedora 8 11/08/2007

sed 's/regexp/replacement/' distros.txt

MM/DD/YYYY format and appears at the end of the line:
[0-9]{2}/[0-9]{2}/[0-9]{4}$
corresponding subexpression in the preceding regular expression:
([0-9]{2})/([0-9]{2})/([0-9]{4})$
\3-\1-\2   gives us the year, a dash, the month, a dash, and the day.

sed 's/([0-9]{2})/([0-9]{2})/([0-9]{4})$/\3-\1-\2/' distros

sed, by default, accepts only basic regular expressions,
several of the characters will be taken as literals,  than as metacharacters. 

backslash to escape the offending characters:
sed 's/\([0-9]\{2\}\)\/\([0-9]\{2\}\)\/\([0-9]\{4\}\)$/\3-\1-\2/' distros.txt

distros.sed -------------------
# sed script to produce Linux distributions report
1 i\
\
Linux Distributions Report\
s/\([0-9]\{2\}\)\/\([0-9]\{2\}\)\/\([0-9]\{4\}\)$/\3-\1-\2/
y/abcdefghijklmnopqrstuvwxyz/ABCDEFGHIJKLMNOPQRSTUVWXYZ/
---------------------------------
sed -f distros.sed distros
Linux Distributions Report
SUSE 10.2 2006-12-07
FEDORA 10 2008-11-25
...
*********Output formatting********************
fmt— A simple text formatter.
printf— Format and print data.
groff— A document formatting system.

nl distros | head  # num line
1 SUSE 10.2 12/07/2006
2 Fedora 10 11/25/2008
3 SUSE 11.0 06/19/2008
...

Table 21-1: nl Markup
Markup 	Meaning
\:\:\: 	Start of logical-page header
\:\: 	Start of logical-page body
\: 		Start of logical-page footer

sed2------------------------------------------------------
# sed script to produce Linux distributions report
1 i\
\\:\\:\\:\
\
Linux Distributions Report\
\
Name Ver. Released\
---- ---- --------\
\\:\\:
s/\([0-9]\{2\}\)\/\([0-9]\{2\}\)\/\([0-9]\{4\}\)$/\3-\1-\2/
$ a\
\\:\
\
End Of Report
-------------------------------------------------------------
sort -k 1,1 -k 2n distros | sed -f sed2 | nl

		Linux Distributions Report
			Name 	Ver. Released
			---- 	---- --------
			1 Fedora 5 2006-03-20
			2 Fedora 6 2006-10-24
			3 Fedora 7 2007-05-31
...
			
			End Of Report
--------------------------------------------------------------
fold: Wrap each line to a specified length.		
echo "The quick brown fox jumped over the lazy dog." | fold -w 12
The quick br
own fox jump
ed over the
lazy dog.
			
echo "The quick brown fox jumped over the lazy dog." | fold -w 12 -s  # -s : fold before the line is reached:
The quick
brown fox
jumped over
the lazy
dog.

pr: Format Text for Printing--------------------------------------------
pr -l 15 -w 65 distros
2012-12-11 		18:27 		distros.txt          Page 1

SUSE 		10.2 	12/07/2006
Fedora 		10 		11/25/2008
SUSE 		11.0 	06/19/2008
Ubuntu 		8.04 	04/24/2008
Fedora 		8 		11/08/2007

2012-12-11 		18:27		 distros.txt         Page 2

SUSE 		10.3 	10/04/2007
Ubuntu 		6.10 	10/26/2006
Fedora 		7 		05/31/2007
Ubuntu 		7.10 	10/18/2007
Ubuntu 		7.04 	04/19/2007
---------------------------------------------------------------------------