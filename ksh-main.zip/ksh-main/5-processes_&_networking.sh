=How a Process Works================
system starts up>>the kernel initiates a few of its own processes and launches init programs >>runs a series of /etc init scripts >>starts system services.
services are implemented as daemon programs, sit in the background and do their thing without having any user interface.

=ps: Viewing Processes===============
$ ps
PID   TTY   TIME     CMD          #TTY :  controlling terminal for the process.
5198  pts/1 00:00:00 bash         #TIME : the amount of CPU time consumed by the process
10129 pts/1 00:00:00 ps

$ ps x | less  #all processes regardless of what terminal
    PID TTY      STAT   TIME COMMAND
   1393 ?        Ss     0:00 /usr/lib/systemd/systemd --user
   1397 ?        S      0:00 (sd-pam)
   1403 ?        S      0:00 sshd: ec2-user@pts/0
   1404 pts/0    Ss     0:00 -bash
   1463 pts/0    R+     0:00 ps x
Process  States============================
R 			Running. process is running or ready to run.
S 			Sleeping. not running;  waiting for an event,a keystroke or network packet.
D 			Uninterruptible sleep. waiting for I/O such as a disk drive.
T			Stopped. 
Z			defunct/“zombie” process.  a child process terminated, but not cleaned up by its parent.
< 			A high-priority process, by giving it more time on the CPU. called niceness.
N 			A low-priority process, a nice process, will get processor time only after other processes with higher priority
----------------------------------------------
$ ps aux
USER 	PID 	%CPU 	%MEM 	VSZ 	RSS 	TTY	 STAT 	START 	TIME 	COMMAND
root 	1 		0.0		 0.0 	2136 	644 	?	 Ss 	Mar05	0:31 	init
root 	2 		0.0 	0.0		 0		 0 		?	 S< 	Mar05 	0:00 	[kt]
root 	3 		0.0 	0.0 	 0 		 0 		? 	 S< 	Mar05 	0:00 	[mi]

VSZ 		Virtual memory size.
RSS 		Resident Set Size. physical memory (RAM)  in kilobytes.
START 		Time when the process started. For values over 24 hours, a date is used.

=top - Viewing Processes Dynamically=================
[me@linuxbox ~]$ top
top - 14:59:20 up 6:30, 2 users, load average: 0.07, 0.02, 0.00
Tasks: 109 total, 1 running, 106 sleeping, 0 stopped, 2 zombie
Cpu(s): 0.7%us, 1.0%sy, 0.0%ni, 98.3%id, 0.0%wa, 0.0%hi, 0.0%si
Mem: 319496k total, 314860k used, 4636k free, 19392k buff
Swap: 875500k total, 149128k used, 726372k free, 114676k cach

PID  USER  PR  NI  VIRT  RES  SHR  S  %CPU  %MEM  TIME+  COMMAND
6244  me   39  19  31752 3124 2188 S  6.3   1.0   16:24.42 trackerd
11071 me   20   0  2304  1092 840  R  1.3   0.3   0:00.14  top
6180  me   20   0  2700  1100 772  S  0.7   0.3    0:03.66 dbus-dae
---------------------------------
Row 	Field 			Meaning
1 		top 			Name of the program.
		14:59:20 		Current time of day.
		up 6:30 		uptime.  amount of time since the the last boot
        2 users         logged in users.
		load average:   Load average refers to the number of processes waiting to run, for the last 1, 5, 15 min. Values < 1.0 ==> not busy.
2 		Tasks:			summarizes the number of processes and their various process states.
		0.7%us 			0.7% of the CPU  used for user processes.
		1.0%sy 			1.0% of the CPU  used for system (kernel)
		0.0%ni 			0.0% of the CPU  used by nice (low-priority)
		98.3%id 		98.3% of the CPU is idle.
		0.0%wa 			0.0% of the CPU is waiting for I/O.
4 		Mem:			 physical RAM is being used.
5 		Swap:			 swap space (virtual memory) 

=bg/fg - Controlling Processes===================
$ xlogo &  # [1] 28236         #Putting a Process in the Background, immune from a CTRL-C.
$ ps
PID TTY TIME CMD
10603 pts/1 00:00:00 bash
28236 pts/1 00:00:00 xlogo
28239 pts/1 00:00:00 ps
$ jobs   # [1]+ Running xlogo &
$ fg %1  # xlogo                  #to the Foreground, To terminate, type CTRL-C.
$ xlogo  # [1]+ Stopped xlogo     #to stop , type CTRL-Z.
$ bg %1  # [1]+ xlogo &

=Signals========================================
 CTRL-C, a signal called INT
 CTRL-Z, a signal called TSTP (Terminal Stop) is sent.

Common Signals  :  kill [-signal] PID...  ========================
Number 		Name 		Meaning
1 			HUP 		Hang up. # by closing a terminal session, many daemon programs to cause a reinitialization, Apache web server 
2 			INT 		Interrupt. # same function as the CTRL-C key , usually terminate a program.
9 			KILL 		Kill. #  kernel immediately terminates, no opportunity to “clean up” after itself or save its work.
15 			TERM 		Terminate. # a program is still “alive” enough to receive signals, it will terminate.
18 			CONT 		Continue. restore a process after a STOP signal.
19 			STOP	    pause without terminating. Like the KILL signal,  not sent to the target process, cannot be ignored.

$ xlogo &        # [1] 13546
$ kill -1 13546  # [1]+ Hangup xlogo

$ xlogo &         # [1] 13601
$ kill -INT 13601 # [1]+ Interrupt xlogo

$ xlogo &         #[1] 13608
$ kill -SIGINT 13608 # [1]+ Interrupt xlogo

$ xlogo &   # [1] 18801
$ xlogo &   # [2] 18802
$ killall xlogo  # send signals to multiple processes, supuer use previliage to kill proc belongs to others
[1]- Terminated xlogo
[2]+ Terminated xlogo

=Other Process-Related Commands=================
Command 			Description
pstree 				parent/child relationships between processes.
vmstat 				Outputs a snapshot of system resource usage (memory, swap, and disk I/O). vmstat 5 (every 5 sec update) 
xload				draws a graph of system load over time.
tload 				draws the graph in the terminal. 

*********Networking****************************************
Monitor the network==================================
ping:        Send an ICMP ECHO_REQUEST to network hosts.
traceroute:  Print the route packets trace to a network host.
netstat:     Print network connections, routing tables, interface statistics, masquerade connections, and multicast memberships.

Transporting files over a Network=====================
ftp:  Internet file transfer program.    lftp: An improved Internet file transfer program.
wget: Non-interactive network downloader.  curl

Secure Communication with Remote Hosts=================
ssh: OpenSSH SSH client (remote login program).
scp: Secure copy (remote file copy program).
sftp: Secure file transfer program.

---------------------------------------------------------------
$ ping linuxcommand.org  #ping: Send a Special Packet to a Network Host= 
PING linuxcommand.org (66.35.250.210) 56(84) bytes of data.

properly performing network: zero percent packet loss. 
A successful ping : indicates elements of the network (its interface cards, cabling, routing, and gateways) in good working order.

$ traceroute slashdot.org   #  a listing of all  “hops” network traffic takes from the local system to a host

 from our test system to http://www.slashdot.org/ requires traversing 16 routers. 
 routers that provide identifying information, hostnames, IP addresses, and performance data including three samples of round-trip time from the local system to the router. 
 For routers that do not provide identifying info (because of router config, network congestion, firewalls, etc.): asterisks in the line.
------------------------------------------------

$ netstat -ie
eth0 Link encap:Ethernet HWaddr 00:1d:09:9b:99:67  # eth0, is the Ethernet interface
inet addr:192.168.1.2 Bcast:192.168.1.255 Mask:255.255.255.0  #inet: valid ip addr . if dhcp is used, used to validate working dhcp
inet6 addr: fe80::21d:9ff:fe9b:9967/64 Scope:Link  
UP BROADCAST RUNNING MULTICAST MTU:1500 Metric:1   # UP, the network interface is enable ( causal network diagnostics)
RX packets:238488 errors:0 dropped:0 overruns:0 frame:0
TX packets:403217 errors:0 dropped:0 overruns:0 carrier:0
collisions:0 txqueuelen:100
RX bytes:153098921 (146.0 MB) TX bytes:261035246 (248.9 MB)
Memory:fdfc0000-fdfe0000

lo Link encap:Local Loopback  #lo, the loopback interface, a virtual interface  that the system uses to talk to itself
inet addr:127.0.0.1 Mask:255.0.0.0
inet6 addr: ::1/128 Scope:Host  #inet: valid ip addr
UP LOOPBACK RUNNING MTU:16436 Metric:1  # UP, the network interface is enable ( causal network diagnostics)
RX packets:2208 errors:0 dropped:0 overruns:0 frame:0
TX packets:2208 errors:0 dropped:0 overruns:0 carrier:0
collisions:0 txqueuelen:0
RX bytes:111490 (108.8 KB) TX bytes:111490 (108.8 KB)

------------------------------------------------------------
netstat -r                               -r option: Kernel IP routing table: network is configured to send packets from network to network.
Destination 	Gateway 	Genmask 		Flags   MSS    Window  irtt     Iface
192.168.1.0 	* 			255.255.255.0 	U 		0      0 	   0 eth0   default  #IP add ends in zero refer to networks rather than individual hosts
192.168.1.1 	0.0.0.0	 	UG 			0 	0 		0      eth0

a typical routing table for a client machine on a (LAN)  behind a firewall/router. 
destination 192.168.1.0. : this destination means any host on the LAN. 
asterisk:  no gateway is needed.

default: any traffic destined for a network that is not otherwise listed in the table. 

the gateway is defined as a router with 192.168.1.1 : knows what to do with the destination traffic.

=Transporting Files over a Network========================

FTP sends account names and passwords in cleartext. ==> almost all FTP done over the Internet is done by anonymous FTP servers.
An anonymous server allows anyone to log in , using the login name anonymous and a meaningless password.

$ ftp fileserver
Connected to fileserver.localdomain.
220 (vsFTPd 2.0.1)

Name (fileserver:me): anonymous
331 Please specify the password.
Password:
230 Login successful.
Remote system type is UNIX.
Using binary mode to transfer files.

ftp> cd pub/cd_images/Ubuntu-8.04 ; ls
ftp> lcd Desktop  #Change the directory on the local system to ~/Desktop.
ftp> get ubuntu-8.04-desktop-i386.iso  #remote system to transfer the file ubuntu-8.04-desktop-i386.iso to the local system.

lftp: A Better ftp, multiple-protocol support (including HTTP), automatic retry on failed downloads, background processes, tab completion of pathnames, and many more.
--------------------------------------------------------------
wget:  Non-interactive Network Downloader (over web or FTP)
[me@linuxbox ~]$ wget http://linuxcommand.org/index.php

Secure Communication with Remote Hosts===================================
ssh—Securely Log in to Remote Computers---------------------

ssh to work: OpenSSH-server package installed, allow incoming network connections on TCP port 22.

ssh remote-sys 'ls * ' > dirlist.txt  : single quote:  want the pathname expansion performed on the remote system.
ssh remote-sys 'ls * > dirlist.txt'   : output redirected to a file on the remote machine

-----------------------------------------------------------------
scp / sftp: Securely Transfer Files

$ scp remote-sys:document.txt .
$ scp bob@remote-sys:document.txt .

sftp-----------------------------------------------------------------
instead of transmitting everything in cleartext, uses an SSH-encrypted tunnel.

sftp requires only the SSH server, not ftp svr. any remote machine with the SSH client can also be used as a FTP-like server.

$ sftp remote-sys
Connecting to remote-sys...
me@remote-sys's password:

sftp> ls            # ubuntu-8.04-desktop-i386.iso 
sftp> lcd Desktop; get ubuntu-8.04-desktop-i386.iso
Fetching /home/me/ubuntu-8.04-desktop-i386.iso to ubuntu-8.04-desktop-i386.iso
/home/me/ubuntu-8.04-desktop-i386.iso 100% 699MB 7.4MB/s 01:35