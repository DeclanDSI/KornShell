***********Environment******************************
Shell variables, environment variables(basically everything else) ,  aliases and shell functions.

Examining the Environment==========
printenv | less
printenv USER # me

set command=================
both the shell, environment vars, and any defined shell functions.
set | less
echo $HOME  #/home/me
alias

Environment Variables================
Variable 		Contents
DISPLAY 		The name of your display if you are running a graphical environment. Usually  :0 (first display by the X server.) 				
EDITOR 			program to be used for text editing.
SHELL 			shell program.
LANG 			Defines the character set and collation order of your language.
OLD_PWD 		The previous working directory.
PAGER 			program to be used for paging output, often set to /usr/bin/less.		
PATH 			A colon-separated list of directories that are searched for executable program
PS1 			Prompt String 1. This defines the contents of your shell prompt.				
PWD 			The current working directory.
TERM			 The name of your terminal type.  this variable sets the protocol to be used with your terminal emulator.		
TZ 				Specifies your time zone. Most Unix-like systems maintain the
				computer’s internal clock in Coordinated Universal Time (UTC)
				and then display the local time by applying an offset specified by this variable.

How Is the Environment Established===========
log on >> the bash program starts >> reads startup config scripts, which define the default environment by all users 
>>more startup files in our personal home.  The exact sequence depends on the type of shell session.

Login vs  Non-login Shells (occurs when we launch a terminal session in the GUI)

Startup Files for Login Shell Sessions----------------------
/etc/profile 			A global configuration script,  all users.
~/.bash_profile 		personal startup file. extend or override settings in the global configuration script.		
~/.bash_login 			If ~/.bash_profile is not found, bash attempts to read this script.					
~/.profile 			If neither ~/.bash_profile nor ~/.bash_login is found,  default in Debian-based, such as Ubuntu.

Startup Files for Non-Login Shell Sessions------------------
/etc/bash.bashrc 		 A global configuration script,  all users.
~/.bashrc 			 personal startup file.  extend or override settings in the global configuration script.
				 most startup files for login shells reads the ~/.bashrc file as well.
--.bash_profile---------------
if [ -f ~/.bashrc ]; then
. ~/.bashrc
fi

User specific environment and startup programs=========
export command:  tells the shell to make the contents of PATH available to child processes of shell.
PATH=$PATH:$HOME/bin && export PATH

Modifying the Environment=============================
-- .bashrc file------------
umask 0002  # Change umask to make directory sharing easier
export HISTCONTROL=ignoredups  # Ignore duplicates in command history
export HISTSIZE=1000  # history size to 1000 lines
alias l.='ls -d .* --color=auto'  # Add some helpful aliases
alias ll='ls -l --color=auto'

Activating Changes----------------
source .bashrc

******How Shell Sees it***************
Wildcards========================
* :Any char , ? :Any single char, [characters] :a member of the set char, negate: [!characters] , [[:class:]] :a member of the specified class

Filename Exp-Wildcard Examples=========
* 				All files
g* 				Any file beginning with g
b*.txt 				b, ending with .txt
Data???				Data followed by exactly three characters
[abc]* 				Any file beginning with either a, b, or c
BACKUP.[0-9][0-9][0-9] 	        Any file beginning with BACKUP, then three numerals
[[:upper:]]* 			Any file beginning with an uppercase letter
[![:digit:]]*			Any file not beginning with a numeral
*[[:lower:]123] 		Any file ending with a lowercase letter OR the numerals 1, 2, or 3

Pathname Expansion====================
echo *s   # Documents Pictures Templates Videos
echo [[:upper:]]*   # Desktop Documents Music Pictures Public Templates Videos
echo .*          # pathname expansin of hidden file
ls -d .[!.]?* # a period> excluding a second period> one additional char> any other chars
echo ~foo  #tilde expansion     /home/foo

Arithmatic expansion==================
echo $((2 + 2))  #  $((expression))  4
echo Five divided by two equals $((5/2))  # Five divided by two equals 2

Brace Expansion=====================
echo Front-{A,B,C}-Back # Front-A-Back Front-B-Back Front-C-Back
echo a{A{1,2},B{3,4}}b  # aA1b aA2b aB3b aB4b
mkdir {2009..2011}-0{1..9} {2009..2011}-{10..12}  # 2009-01 2009-07 2010-01 2010-07 2011-01 2011-07 ...

Param Expansions====================
echo $USER # me
printenv | less  #see a list of available variables

Command Substitution==================
ls -l $(which cp) # -rwxr-xr-x 1 root root 71516 2012-12-05 08:58 /bin/cp
file $(ls /usr/bin/* | grep zip)

Double vs single  Quotes=============
Parameter&arithmetic expansion & cmd substitution--> double quote
$ echo "$USER $((2+2)) $(cal)"
me 4 February 2012
Su Mo Tu We Th Fr Sa
1 2 3 4
5 6 7 8 9 10 11
12 13 14 15 16 17 18
19 20 21 22 23 24 25
26 27 28 29

$ echo $(cal)
February 2012 Su Mo Tu We Th Fr Sa 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17
18 19 20 21 22 23 24 25 26 27 28 29

$ echo "$(cal)"
February 2012
Su Mo Tu We Th Fr Sa
1 2 3 4
5 6 7 8 9 10 11
12 13 14 15 16 17 18
19 20 21 22 23 24 25
26 27 28 29

parameter/arithmetic expansion, and command substitution still carried out.
$ echo text ~/*.txt {a,b} $(echo foo) $((2+2)) $USER
text /home/me/ls-output.txt a b foo 4 me

$ echo "text ~/*.txt {a,b} $(echo foo) $((2+2)) $USER"
text ~/*.txt {a,b} foo 4 me   

$ echo 'text ~/*.txt {a,b} $(echo foo) $((2+2)) $USER'  # Single Qutoes: suppress all expansions
text ~/*.txt {a,b} $(echo foo) $((2+2)) $USER

Escaping characters============
echo "The balance for user $USER is: \$5.00"    # $: \, backtick  #The balance for user me is: $5.00

*****Parameter Expansion***string&number****************
Basic Parameters=======
a="foo" && echo "$a_file"  ; echo "${a}_file"  # ''   # foo_file

Expansions, to Manage Empty Variables========
${parameter:-word}  unset param or empty value results in the value of the word
foo=    && echo ${foo:-"substitute value if unset"} ; echo $foo    #substitute value if unset  #null
foo=bar && echo ${foo:-"substitute value if unset"} ; echo $foo    #bar                        # bar
TARGET="${DEPLOYMENT}:${PKGNAME}:[^:]*${PKGAS:-:}${PKGOS:-:}${PKGBR:-:}-?${PREVIOUS_VER}\$"
{parameter:=word}
foo=    && echo ${foo:="default value if unset"}   ; echo $foo     #default value if unset     #default value if unset
foo=bar && echo ${foo:="default value if unset"}   ; echo $foo     #bar                        #bar

${parameter:?word}  If parameter is unset or empty,  exit with an error
foo=    && echo ${foo:?"parameter is empty"}       ; echo $?       #bash: foo: parameter is empty  #1 
foo=bar && echo ${foo:?"parameter is empty"}       ; echo $?       #bar                            #0

${parameter:+word} unset/empty param, the expansion results in nothing. 
foo=    && echo ${foo:+"substitute value if set"}  ; echo $foo     #' '                          #null
foo=bar && echo ${foo:+"substitute value if set"}  ; echo $foo     #substitute value if set      #bar

Expansions -That Return Variable Names============
${!prefix*}  ${!prefix@}  # both acts as same

echo ${!BASH*}  # list all the Emn vars begins with BASH
BASH BASH_ARGC BASH_ARGV BASH_COMMAND BASH_COMPLETION BASH_COMPLETION_DIR
BASH_LINENO BASH_SOURCE BASH_SUBSHELL BASH_VERSINFO BASH_VERSION

String - Operations==============================
${#parameter} : Normally, parameter is a string; however, either @ or *, then the expansion results in the number of positional parameters.
foo="This string is long." && echo "'$foo' is ${#foo} characters long."   # 20 

${parameter:offset}    ${parameter:offset:length}
foo="This string is long." ; echo ${foo:5}    ; echo ${foo:5:6}      # string is long.   # string
foo="This string is long." ; echo ${foo: -5}  ; echo ${foo: -5:2}    # long.             # lo      #a space to prevent confusion with  ${parameter:-word}

{parameter#pattern}   ${parameter##pattern}  # removes the shortest/longest match
foo=file.txt.zip && echo ${foo#*.}  ; echo ${foo##*.}  # txt.zip    # zip

${parameter%pattern}   ${parameter%%pattern}   # remove from the end of the string
foo=file.txt.zip && echo ${foo%.*}   ; echo ${foo%%.*} # file.txt    # file

String - search and replace===============================
${parameter/pattern/string}    :the text matched by pattern to be deleted
${parameter//pattern/string}   :all occurrences are replaced
${parameter/#pattern/string}   :the match occur at the beginning of the string
${parameter/%pattern/string}   :the match to occur at the end of the string

foo=JPG.JPG; echo ${foo/JPG/jpg} ; echo ${foo//JPG/jpg}    # jpg.JPG   # jpg.jpg
echo ${foo/#JPG/jpg}; echo ${foo/%JPG/jpg}    # jpg.JPG   # JPG.jpg
---------------------------------------------------------------
#$((expression)): Arithmetic Evaluation and Expansion
#use $((expression) and find longest string in a file
for i; do
        if [[ -r $i ]]; then
                max_word=
                max_len=
                for j in $(strings $i); do
                        len=${#j}  # $(echo $j | wc -c)  command substitution
                        if (( len > max_len )); then
                                max_len=$len
                                max_word=$j
                        fi
                done
                echo "$i: '$max_word' ($max_len chacracters)"
        fi
        shift
done
---------------------------------------------------------------
$ time ./exp.sh dirlist-usr-bin.txt
dirlist-usr-bin.txt: 'scrollkeeper-get-extended-content-list' (38 characters)
real 0m0.060s
user 0m0.056s
sys 0m0.008s

-------------------------------------------
#modulo :demonstrate the modulo operator
for ((i = 0; i <= 20; i = i + 1)); do
        remainder=$((i%5))
        if ((remainder == 0 )); then
                printf "<%d>" $i
        else
                printf "%d" $i
        fi
done
printf"\n"
------------------------------------------
modulo
<0> 1 2 3 4 <5> 6 7 8 9 <10> 11 12 13 14 <15> 16 17 18 19 <20>

parameter = value 		Simple assignment. Assigns value to parameter.
parameter += value 		parameter = parameter +value.
parameter -= value 		parameter = parameter –value.
parameter *= value 		Multiplication.  parameter = parameter ×value.
parameter /= value 		Integer division. parameter = parameter ÷value.
parameter %= value 		Modulo.  parameter = parameter % value.

parameter++ 	         post-increment. parameter =parameter + 1.
parameter-- Variable 	 post-decrement. parameter =parameter - 1.
++parameter Variable	 pre-increment.  parameter =parameter + 1.
--parameter Variable 	 pre-decrement.  parameter =parameter - 1.

placed after the param => the operation performed after the parameter is returned. 
place before the parm  => the parameter is incremented (or decremented) before the parameter is returned. 

foo=1 ;  echo $((foo++)) ; echo $foo   # 1  # 2
foo=1 ;  echo $((++foo)) ; echo $foo   # 2  # 2
----------------------------------------
#!/bin/bash
for (( i = 0; i <= 20; ++i )); do
        if (((i%5) == 0 )); then
                printf "<%d>" $i
        else
                printf "%d" $i
        fi
done
printf "\n"
------------------------------
Bit Operators
Operator        Description
# ~ 	        Bitwise negation. Negate all the bits in a number.
# << 	        Left bitwise shift.  Shift all the bits in a number to the left.
# >>		Right bitwise shift. Shift all the bits in a number to the right.
# & 		Bitwise AND. Perform an AND operation on all the bits in two numbers.
# | 		Bitwise OR.  Perform an OR operation on all the bits in two numbers.
# ^ 		Bitwise XOR. Perform an exclusive OR operation on all the bits in two numbers. 

for ((i=0;i<8;++i)); do echo $((1<<i)); done  # producing a list of powers of 2
1
2
4
8
16
32
64
128

Logic==============================================
Operator Description  # the (( )) compound command supports a variety of comparison operators
<= 	Less than or equal to  >= Greater than or equal to
< 	Less than              >  Greater than
== 	Equal to               != Not equal to
&& 	Logical AND            || Logical OR

expressions:  0 == false, non-zero expressions==true. 
The (( )) compound command:  maps the results into the shell’s normal exit codes:                                                                                           
if ((1)); then echo "true"; else echo "false"; fi # true
if ((0)); then echo "true"; else echo "false"; fi # false                                                     

expr1?expr2:expr3  # Comparison operator. If  expr1 evaluates to be non-zero (arithmetic true) then expr2, else expr3.
a=0  && ((a<1?++a: --a)) &&  echo $a  # 1
((a<1?++a: --a)) &&  echo $a          # 0
----------------------------------------------------------
#!/bin/bash
# arithmetic loop ops, \t format
finished=0
a=0
printf "a\ta**2\ta**3\n"
printf "=\t====\t====\n"
until ((finished)); do
                                b=$((a**2))
                                c=$((a**3))
                                printf "%d\t%d\t%d\n" $a $b $c
                                ((a<10?++a: (finished=1)))
done
---------------------------------------------------------
[me@linuxbox ~]$ ./loop.sh
a              a**2         a**3
=              ====         ====
0              0            0
1              1            1
2              4            8
3              9            27
4              16           64
5              25           125
6              36           216
7              49           343
8              64           512
9              81           729
10             100 	    1000

---------------------------------------------------------
#  calculate monthly loan payments
PROGNAME=$(basename $0)
usage () {
        cat <<- EOF
        Usage: $PROGNAME PRINCIPAL INTEREST MONTHS
                                               
        Where:
        PRINCIPAL is the amount of the loan.
        INTEREST is the APR as a number (7% = 0.07).
        MONTHS is the length of the loan's term.
EOF
         }
                                               
if (($# != 3)); then
        usage; exit 1
fi
 
principal=$1
interest=$2
months=$3

 # bc: An Arbitrary-Precision Calculator Language
bc <<- EOF  
        scale = 10
        i = $interest / 12
        p = $principal
        n = $months
        a = p * ((i * ((1 + i) ^ n)) / (((1 + i) ^ n) - 1))
        print a, "\n"
EOF
-----------------------------------------------------------
$ loan-calc 135000 0.0775 180
1270.7222490000
---------------------------------------------------------
























