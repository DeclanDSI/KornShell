﻿Exit Status===========================
ls -d /usr/bin;  echo $?    # /usr/bin   # 0
ls -d /bin/usr;  echo $?    # ls: cannot access /bin/usr: No such file or directory   # 1

true or false==========================
true  &&  echo $?   # 0
false &&  echo $?   # 1

if true;  then echo "It's true."; fi  # It's true.
if false; then echo "It's true."; fi  # [me@linuxbox ~]$
if false; true;  then echo "It's true."; fi  # It's true.
if true ; false; then echo "It's true."; fi  # [me@linuxbox ~]$

Using test================================
test expression --->  [ expression ]
test - File Expressions======================
file1 -ef file2         same inode numbers (two filenames refer to the same file by hard linking).
-L file 		symbolic link.
file1 -nt file2         file1 is newer than file2.
file1 -ot file2 	file1 is older than file2.
-b file 		block-special (device) file.
-c file 		character-special (device) file.
-e file 		file exists.
-d file 		directory.
-f file 		regular file.
-k file 		“sticky bit” set.
-p file 		named pipe.
-s file 		a length greater than zero.
-S file                 a network socket.
-t fd 			fd is a file descriptor directed to/from the terminal. to determine whether standard input/output/ error is being redirected.
-G file 		owned by the effective group ID.
-O file 		owned by the effective user ID.
-u file 		setuid.
-g file 		set-group-ID.
-r file 		readable (has readable permission for the effective user).
-w file 		writable (has write permission for the effective user).
-x file 		executable (has execute/search permission for the effective user).

the exit commands with return statements----------------------
test_file () {
FILE=~/.bashrc
if [ -e "$FILE" ]; then
	if [ -f "$FILE" ]; then
		echo "$FILE is a regular file."
	fi

	if [ -d "$FILE" ]; then
		echo "$FILE is a directory."
	fi

	if [ -r "$FILE" ]; then
		echo "$FILE is readable."
	fi

	if [ -w "$FILE" ]; then
		echo "$FILE is writable."
	fi

	if [ -x "$FILE" ]; then
		echo "$FILE is executable/searchable."
	fi
else
	echo "$FILE does not exist"
	return 1   # exit 1 ,if it was a script, not as a function.
fi
}
String Expressions==========================
string 			not null.
-n string 		The length is greater than zero.
-z string 		The length is zero.
string1 = string2 vs. string1 == string2
string1 != string2 	not equal.
string1 > string2 	string1 sorts after string2.
string1 < string2 	string1 sorts before string2.

A More Modern Version of test===============
expression evaluates to either a true or false result.
similar to test (it supports all of its expressions) but adds a new string expression: string1 =~ regex

FILE=foo.bar; if [[ $FILE == foo.* ]]; then echo "$FILE matches pattern 'foo.*'" ; fi
---------------------------------------
INT=-5
if [[ "$INT" =~ ^-?[0-9]+$ ]]; then  # Added feature of [[ ]] :  == operator supports pattern matching.
	if ((INT == 0)); then
		echo "INT is zero."
else
		if ((INT < 0)); then
			echo "INT is negative."
		else
			echo "INT is positive."
		fi
		if (( ((INT % 2)) == 0 )); then   # (( )): Designed for Integers
			echo "INT is even."
		else
			echo "INT is odd."
		fi
	fi
else
	echo "INT is not an integer." >&2
	exit 1
fi

Expressions - Logical Operators======================
Operation     test        [[ ]] and (( ))
AND           -a            &&
OR            -o            ||
NOT            !             !
---------------------------------------
MAX_VAL=100
INT=50
if [[ "$INT" =~ ^-?[0-9]+$ ]]; then
		if [[ INT -ge MIN_VAL && INT -le MAX_VAL ]]; then  # two expressions separated by the && operator
				echo "$INT is within $MIN_VAL to $MAX_VAL."
		else
				echo "$INT is out of range."
		fi
else
		echo "INT is not an integer." >&2
		exit 1
fi
------------------------------------------->>
if [ $INT -ge $MIN_VAL -a $INT -le $MAX_VAL ]; then
		echo "$INT is within $MIN_VAL to $MAX_VAL."
else
		echo "$INT is out of range."
fi

test vs. [[ ]] =============================
test is traditional (and part of POSIX), whereas [[ ]] is specific to bash. 
test is very widely used, but [[ ]] is clearly more useful, easier to code.
------------------------------------------>>
if [[ ! (INT -ge MIN_VAL && INT -le MAX_VAL) ]]; then
	echo "$INT is outside $MIN_VAL to $MAX_VAL."
else
	echo "$INT is in range."
fi
------------------------------------------->>
# < >  ( ) , grouping in test, must be quoted or escaped.
if [ ! \( $INT -ge $MIN_VAL -a $INT -le $MAX_VAL \) ]; then
		echo "$INT is outside $MIN_VAL to $MAX_VAL."
else
		echo "$INT is in range."
fi

Control Operators: Another Way to Branch===========
command1 && command2  #and
command1 || command2  #or

$ mkdir temp && cd temp
$ [ -d temp ] || mkdir temp
$ [ -d temp ] || exit 1

---/etc/cron.d/sample_cronjob.sh-----------
min(0-59)/hour(0-23)/dayofmonth(1-31)/month(1-12)/dayofweek(0-6)
7 16 * * 0  #every Sunday at seven min past 4:00
----evenweek------------------------------
<<desc
+%V: ISO week number, the week number of year
desc
evenweek=$[ $(date +%V)%2 ]   #even number for the week
if [[ $evenweek -eq 0 ]];then
	echo "evenweek execution" | mail -s "evenweek execution" abc@abc.com
else
	echo "BAU execution" | mail -s "BAU execution" abc@abc.com
fi

*************loop*****************
ForLoop==============
if [[ "$#" -eq 0 ]]; then
	echo -e "\nError | no filename specified"
	echo -e "\nUsage $(basename $0) <filename>\n"
	exit 1
fi

for i; do   # for n number of args
	check=$(file $1 | cut -d " " -f2)
	filename="$1"
		case $check in 
			"ASCII")
				echo -e "\nFile $filename is a plain text file"
			;;
			"Bourne-Again")
				echo -e "\nFile $filename is a script file"
			;;
			"ELF")
				echo -e "\nFile $filename is an executable"
			;;
			*)
				echo -e "\nFiletype can't be verified"
		esac
	shift  #shift to next arg
done

report_home_space () {
        local format="%8s%10s%10s\n"
        local i dir_list user_name total_dirs total_files total_size 

        if [[ $(id -u) -eq 0 ]]; then
                dir_list=/home/*
                user_name="All Users"
        else
                dir_list=$HOME
                user_name=$USER
        fi
echo "Home Space Utilization ($user_name)"
for i in $dir_list; do
        total_dirs=$(find $i -type d | wc -l)
        total_files=$(find $i -type f | wc -l)
        total_size=$(du -sh $i | cut -f 1)
        echo "$i"
        printf "$format" "Dirs" "Files" "Size"
        printf "$format" "----" "----" "----"
        printf "$format" $total_dirs $total_files $total_size
done
}
report_home_space

==while/break/continue========================
echo "count down prior to next execution"
count=1
while [ $count -le 5 ]; do
	echo $count
	count=$((count + 1))
done
	echo "While test Finished."
	echo "next break/continue code execution starts now"

#break/continue==========================
echo "1>> --test: break---"
for i in 3,2,1 "executed"; do
	if [[ "$1" = "break" ]]; then
                echo "echo just before break"
		echo "2>> break executed"
		break  # exit the loop
	fi
	echo "3>> " $i   # code not executed with break
echo "4>> next code execution starts now"
echo "5>> --test: continue---"
	if [[ "$1" = "continue" ]]; then
                echo "echo just before continue"
		echo "6>> continue executed"
		continue  # back to the loop
	fi
	echo "7>> " $i   # code not executed with contniue
done
echo "8>> next code execution starts now"
**************for loop*********************** #1227
while==========================================
(( expression1 )) #initialize 
	while (( expression2 )); do  # determine when the loop is finished
		commands
		(( expression3 ))    # carried out at the end of each iteration of the loop.
	done
For--------------------------------------------->>
for (( expression1; expression2; expression3 )); do commands; done
for (( i=0; i<5; i=i+1)); do echo $i;  done

for i in {A..D};do echo $i; done
for i in distros*.txt; do echo $i; done  # pathname expansion
--------------------------------------------------
# find longest string in a file
maxword(){
        if [[ -r $1 ]]; then
                max_word=
                max_len=0
                for i in $(strings $1); do
                        len=$(echo $i | wc -c)
                        if (( len > max_len )); then
                                max_len=$len
                                max_word=$i
                        fi
                done
                echo "$1: '$max_word' ($max_len characters)"
        fi
}
while [[ -n $1 ]]; do
        maxword $1
        shift
done
---------------------------------------------------------->>
for i; do
        maxword $1
done
------------------------------------------------------------
*****FlowControl-case*****************
case:  multiple-choice compound command
----------------------------------------------------
clear
echo " please select:
                1. Display system info
                2. Display Disk Space
                3. Display Home Space Utilization
                0. Quit "
read -p "Enter selection [0-3] > "

if [[ $REPLY =~ ^[0-3] ]]; then
        if [[ $REPLY == 0 ]]; then
                echo "Program terminated"
                exit
        fi
        if [[ $REPLY == 1 ]]; then
                echo "Hostname: $HOSTNAME"
                uptime
                exit
        fi
        if [[ $REPLY == 2 ]]; then
                df -h
                exit
        fi
        if [[ $REPLY == 3 ]]; then
                if [[ $(id -u) -eq 0 ]]; then
                        echo "Home Space Utilization ( All Users)"
                        du -sh /home/*
                else
                        echo "HOME Space Utilization ($USER)"
                        du -sh $HOME
                fi
                exit
        fi
else
        echo "Invalid entry" >&2
        exit 1
fi

with case-------------------------------->>
clear
echo "please select:
        1. Display system info
        2. Display Disk Space
        3. Display Home Space Utilization
        0. Quit"
read -p "Enter selection [0-3] > "

case $REPLY in
0)
        echo "program terminated"
        exit
        ;;
1)
        echo "Hostname: $HOSTNAME"
        uptime
        ;;
2)
        df -h
        ;;
3)
        if [[ $(id -u) -eq 0 ]]; then
                echo "home space utilization ( All Users)"
                du -sh /home/*
        else
                echo "home space utilization ($USER)"
                du -sh $HOME
        fi
        ;;
*)
        echo "Invalid entry" >&2
        exit 1
        ;;

Patterns============================================
read -p "enter word > "
case $REPLY in
        [[:alpha:]]) echo "is a single alphabetic character." ;;     
        [ABC][0-9])  echo " is A,B, or C followed by a digit" ;;
        ???)         echo "is three characters long" ;;
        *.txt)       echo "is a word ending in .txt" ;;  
        *)           echo "is something else" ;;   # Matches any value of word.
esac
Combining Multiple Patterns---------------------------->>
clear
echo " please select:
        A. Display system info
        B. Display Disk Space
        C. Display Home Space Utilization
        0. Quit"
read -p "Enter selection [0-3] > "
case $REPLY in
q|Q)
        echo "program terminated"
        exit
        ;;
a|A)
        echo "Hostname: $HOSTNAME"
        uptime
        ;;
b|B)
        df -h
        ;;
c|C)
        if [[ $(id -u) -eq 0 ]]; then
                echo "home space utilization ( All Users)"
                du -sh /home/*
        else
                echo "home space utilization ($USER)"
                du -sh $HOME
        fi
        ;;
*)
        echo "Invalid entry" >&2
        exit 1
        ;;
esac
----------------------------------------------------------
<<desc
#unset -f <function> : take out function from memory
#declare -f : see a list of functions defined in our current bash env
#Bash searches : Aliases >> Functions >> Built-ins >> $PATH
desc

match_process()
{
        while [[ "$answer" != "processA" ]]; do
                read -p "Enter the name of matching process" answer
                if [[ "$answer" == "processA" ]]; then
                        tput clear #terminal
                        echo "matching successful"
                        answer=
                        return
                else
                        echo "matching failed"
                fi
        done
}

options="processA processB processC"
echo -e "\nSelect the matching process \n"
PS3="Select choice:"  #menu with PS3 prompt

select choice in $options; do   # select in ;do; done
        echo "REPLY variable is $REPLY"
        echo "choice variable is $choice"
        case $choice in         #case in  esac
                "processA")
                        echo -e "\nMatching successful, processA"
                        break
                ;;
                "processB")
                        echo -e "\nprocessB selected\n"
                        match_process
                        break
                ;;
                "processC")
                        echo -e "\nprocessC selected\n"
                        match_process
                        break
                ;;
                *)
                        echo -e "\nSelect among valid processes"
                ;;
        esac
done



