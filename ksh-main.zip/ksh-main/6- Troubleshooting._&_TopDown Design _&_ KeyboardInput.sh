

1. Syntactic Errors- Missing Quotes /unexpected tokens :  if vim installed,:syntax on

2. Syntactic Errors - Unanticipated Expansions=========================
number=   
if [ $number = 1 ]; then  # [ = 1 ]
        echo "Number is equal to 1"
else
        echo "Number is not equalt to 1"
fi

#scenario 2: 
[ "$number" = 1 ] when expansion occurs, [ "" = 1 ] which yields the correct number of args.

3. Logical errors: unlike syntatic errors, logical erros do not prevent a script from running==============
-Incorrect conditional expressions
-Off by one” errors: counting start with 0, rather than 1
-Unanticipated situations: unanticipated expansions, filename embedded spaces expand into multiple args

3.1 Defensive Programming===============
cd $dir_name ; rm *  # $dir_name does not exit, it will delete the current working directory

-----------------------------------
cd $dir_name && rm *                         # make the execution of rm contingent on the success of cd
[[ -d $dir_name ]] && cd $dir_name && rm *   # check dir_name actually contains the name of an existing directory
4. Testing ============================
#echo use
if [ $var -ge 5 ]
    echo "Inside if statement"
    <code>
    <code>
    <code>
fi
-----------------------------------
if [[ -d $dir_name ]]; then            #test1: dir_name contains the name of an existing directory.
		if cd $dir_name; then          #test2: dir_name contains the name of a nonexistent directory.
				rm *
		else
			echo "cannot cd to '$dir_name'" >&2
			exit 1             # descriptive err msg to std err, terminates with an exit
		fi
else
		echo "no such directory: '$dir_name'" >&2  #test 3: dir_name is empty
		exit 1
fi



5. Debugging=====tracing/commentout/-x====================
echo "preparing to delete files" >&2   # Tracing: view the actual flow of the program
if [[ -d $dir_name ]]; then
        if cd $dir_name; then
                echo "deleting files" >&2
                echo rm *  # commenting out the problem area. i.e. file-deletion 
        else
                echo "cannot cd to '$dir_name' " >&2
                exit 1
        fi

else
        echo " no such directory: '$dir_name'" >&2
        exit 1
fi
echo "file deletion complete" >&2
--------------------------------------------
export PS4='$LINENO + '  # current line number
trouble
5 + number=1
7 + '[' 1 = 1 ']'
8 + echo 'Number is equal to 1.'
------------------------------------------------
number=1
echo "number=$number"     # DEBUG:  Exam values during execution-
set -x # Turn on tracing
	if [ $number == 1 ]; then
		echo "Number is equal to 1."
	else
		echo "Number is not equal to 1."
	fi
set +x # Turn off tracing

6. Exit status------------------------------
$ cp ; echo $? #  cp: missing file operand   # 1
cp ./ftest.sh ./bkp_ftest.sh;  echo $?   #0

script File Location============
$ echo $PATH
/home/me/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
$ mv hello_world bin &&  hello_world
Hello World!

export PATH=~/bin:"$PATH" ;  . .bashrc  #add this line in our .bashrc file:   # apply the change to the current terminal session

good location for scripts-------
-everyone    : /usr/local/bin.
-system admin: /usr/local/sbin
-locally supplied software, scripts or compiled programs: /usr/local
-Linux distributor: /bin or /usr/bin


command << token
text
token

<<'EOF'
comment out block
EOF
------------------------
foo="some text"
cat <<'EOF'
> $foo
> "$foo"
> '$foo'
> \$foo
EOF
----------------------
some text
"some text"
'some text'
$foo

*****TopDown Design**************************
create these additional commands two ways======================
function name {
commands
return
}
-----------------------------------
name () {
commands
return
}
local variables=====================================
foo=0 # global variable foo
funct_1 () {
local foo 
foo=1; echo "funct_1: foo = $foo"}
funct_2 () {
local foo 
foo=2; echo "funct_2: foo = $foo"}

echo "global: foo = $foo"
funct_1
echo "global: foo = $foo"
funct_2
echo "global: foo = $foo"
------------------------------------------
$ local-vars
global: foo = 0
funct_1: foo = 1
global: foo = 0
funct_2: foo = 2
global: foo = 0

**********keyboard input*************
echo -n "Please enter an integer -> "
read int
if [[ "$int" =~ ^-?[0-9]+$ ]]; then  # evaluate the value of an integer.
		if [ $int -eq 0 ]; then
			echo "$int is zero."
		else
			if [ $int -lt 0 ]; then
				echo "$int is negative."
			else
				echo "$int is positive."
			fi
			if [ $((int % 2)) -eq 0 ]; then
				echo "$int is even."
			else
				echo "$int is odd."
			fi
		fi
	else
		echo "Input value is not an integer." >&2
		exit 1
fi


^ indicates the start of the string
-? matches an optional hyphen (-)
[0-9] matches any digit from 0 to 9
+ indicates that the preceding character or character class (in this case, [0-9]) should be matched one or more times
$ indicates the end of the string
------------------------------
#!/bin/bash
# read  multiple values from keyboard
echo -n "Enter one or more values > "
read var1 var2 var3 var4 var5
echo "var1 = '$var1'"
echo "var2 = '$var2'"
echo "var3 = '$var3'"
echo "var4 = '$var4'"
echo "var5 = '$var5'"

Enter one or more values > a              # var1 = 'a' ... var5 = ''
Enter one or more values > a b c d e f g  # var1 = 'a' ... var5 = 'e f g'
-------------------------------------------
read -p "Enter one or more values > " ; echo "REPLY = '$REPLY'"
---------------------------------------------------------
# input a secret passphrase
if read -t 10 -sp "Enter secret passphrase > " secret_pass; then  # -t ,-s  : timeout, secret
	echo -e "\nSecret passphrase = '$secret_pass'"
else
	echo -e "\nInput timed out" >&2
	exit 1
fi
-------------------------------
FILE=/etc/passwd
read -p "Enter a username > " user_name
file_info=$(grep "^$user_name:" $FILE) 
OLD_IFS="$IFS"
if [ -n "$file_info" ]; then
	IFS=":" read user pw uid gid name home shell <<< "$file_info" 
	echo "User = '$user'"
	echo "UID = '$uid'"
	echo "GID = '$gid'"
	echo "Full Name = '$name'"
	echo "Home Dir. = '$home'"
	echo "Shell = '$shell'"
else
	echo "No such user '$user_name'" >&2
	exit 1
fi
IFS="$OLD_IFS"
-----------------------------
"you can't pipe read"==========
| creates  subshells,  never alter the environment of its parent process. 
read assigns var, which then become part of the subshell env.
but when the command exits, the subshell env are destroyed, and the effect of the assignment is lost.
echo "foo" | read # REPLY variable will always be empty

Validating Input==========================
#!/bin/bash
invalid_input () {
	echo "Invalid input '$REPLY'" >&2
	exit 1
}

read -p "Enter a single item > "
[[ -z $REPLY ]] && invalid_input
(( $(echo $REPLY | wc -w) > 1 )) && invalid_input #input is multiple items (invalid)

# is input a valid filename?
if [[ $REPLY =~ ^[-[:alnum:]\._]+$ ]]; then
	echo "'$REPLY' is a valid filename."
		if [[ -e $REPLY ]]; then
				echo "And file '$REPLY' exists."
		else
				echo "However, file '$REPLY' does not exist."
		fi
	
	# is input a floating point number?
		if [[ $REPLY =~ ^-?[[:digit:]]*\.[[:digit:]]+$ ]]; then
				echo "'$REPLY' is a floating point number."
		else
				echo "'$REPLY' is not a floating point number."
		fi
	
	# is input an integer?
		if [[ $REPLY =~ ^-?[[:digit:]]+$ ]]; then
				echo "'$REPLY' is an integer."
		else
				echo "'$REPLY' is not an integer."
		fi
else
	echo "The string '$REPLY' is not a valid filename."
fi



^ indicates the start of the string
-? matches an optional hyphen (-)
[[:digit:]]* matches zero or more digits
\. matches a period (\. must be escaped with a backslash to match a literal period)
[[:digit:]]+ matches one or more digits
$ indicates the end of the string
----------------------------------------------
clear
echo "
Please Select:
1. Display System Information
2. Display Disk Space
3. Display Home Space Utilization
0. Quit
"
read -p "Enter selection [0-3] > "

if [[ $REPLY =~ ^[0-3]$ ]]; then
		if [[ $REPLY == 0 ]]; then
				echo "Program terminated."
				exit
		fi
		
		if [[ $REPLY == 1 ]]; then
			echo "Hostname: $HOSTNAME"
			uptime
			exit
		fi

		if [[ $REPLY == 2 ]]; then
			df -h
			exit
		fi
		
		if [[ $REPLY == 3 ]]; then
				if [[ $(id -u) -eq 0 ]]; then
					echo "Home Space Utilization (All Users)"
					du -sh /home/*
				else
					echo "Home Space Utilization ($USER)"
					du -sh $HOME
				fi
				exit
		fi
else
	echo "Invalid entry." >&2
	exit 1
fi
-------------------------------------------------------
