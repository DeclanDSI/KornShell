locate: Find files by name.  vs   find: Search for files in a directory hierarchy.
xargs: Build and execute command lines from standard input.
touch: Change file times.
stat: Display file or filesystem status

$ locate zip | grep bin  #run the updatedb program manually by becoming the superuser 
/bin/bunzip2    #updatedb once a day,as a cron job.  very recent files do not show up when using locate.
/usr/bin/gpg-zip

find ~ -type d | wc -l #1695
find ~ -type f | wc -l #38737
find ~ | wc -l #47068
find ~ -type f -name "*.JPG" -size +1M | wc -l  #840,   *.JPG and  larger than 1 megabyte 

Character size Unit >> b: 512-byte blocks  c: Bytes  w: 2-byte words k: Kilobytes(1024 bytes) M: Megabytes(1,048,576 bytes)  G:Gigabytes

Find - Test Description >>  match files/directories (c: content/attr changes  ,  m: modified) 
-cmin n  		exactly n minutes ago. fewer than n minutes ago: -n (vs. +n)
-cnewer file 		more recently than those of file.
-ctime n 		contents/ attributes (i.e.,permissions) , n*24 hours ago.

-empty 			empty 
-name pattern 		specified wildcard pattern.
-iname pattern 	        -name test ,with case insensitive.

-inum n 		inode number n. hard links to a particular inode.
-samefile name 		same inode number, as file name.
-mmin n 		n minutes ago.
-mtime n 		n*24 hours ago.

-newer file 		than the specified file. each backup, update a file (such as a log) ,locate changed files since the last update.
-size n 		size n.
-type c 		type c.

-nouser 		do not belong to a valid user. (deleted accounts/detect activity by attackers)
-nogroup 		do not belong to a valid group.
-user name 		belonging to name/uid.
-group name 		belonging to group name/gid
-perm mode 		permissions set to the specified mode.

find ~ \( -type f -not -perm 0600 \) -or \( -type d -not -perm 0700 \)
find ~ -type f -name '*.BAK' -delete
find ~ -type f -name 'foo*' -exec ls -l '{}' ';' # execute ls each time a matching file is found
find ~ -type f -name 'foo*' -exec ls -l '{}' +   # same results, but the system has to execute the ls command only once.
find ~ -type f -name 'foo*' -print | xargs ls -l # xargs takes standard input and converts it into an argument list for a specified command.
find ~ -iname '*.jpg' -print0 | xargs --null ls -l #all files containing embedded spaces in their names, are handled correctly. print0: produces nullseparated output
                                                   # xargs with -null : accepts null separated input

mkdir -p playground/dir-{00{1..9},0{10..99},100} && touch playground/dir-{00{1..9},0{10..99},100}/file-{A..Z}
find playground -type f -name 'file-A'
find playground -type f -name 'file-A' | wc -l  #100
touch playground/timestamp

stat playground/timestamp
'File: 'playground/timestamp'
Size: 0 Blocks: 0 IO Block: 4096 regular empty file
Device: 803h/2051d Inode: 14265061 Links: 1
Access: (0644/-rw-r--r--) Uid: ( 1001/ me) Gid: ( 1001/ me)
Access: 2012-10-08 15:15:39.000000000 -0400
Modify: 2012-10-08 15:15:39.000000000 -0400
Change: 2012-10-08 15:15:39.000000000 -0400'

find playground -type f -name 'file-B' -exec touch '{}' ';'
find playground -type f -newer playground/timestamp
find playground \( -type f -not -perm 0600 \) -or \( -type d -not -perm 0700 \)
find playground \( -type f -not -perm 0600 -exec chmod 0600 '{}' ';' \) -or \( -type d -not -perm 0700 -exec chmod 0700 '{}' ';' \)

**************Regular expressions***********************************
grep—Search Through Text=========================
$ ls /usr/bin | grep zip

grep Option Description:
-i  Ignore case. 
-v  Invert match.
-c  Print the number of matches 
-l  Print the file name (inverse match: -L )	
-n  line num
-h  multifile searches, suppress filename
	
ls /bin > dirlist-bin.txt ; ls /usr/bin > dirlist-usr-bin.txt ; ls /sbin > dirlist-sbin.txt; ls /usr/sbin > dirlist-usr-sbin.txt; ls dirlist*.txt
grep bzip dirlist*.txt # dirlist-bin.txt:bzip2    dirlist-bin.txt:bzip2recover
grep -l bzip dirlist*.txt #  list filename with content match
grep -L bzip dirlist*.txt # list filename with  inverse content match

==Metacharacters and Literals=======================
regular expressions :may include metacharacters => specify more complex matches => special meaning to shell
^ $ . [ ] { } - ? * + ( ) | \

Any Character .  ----------metacharacters enclosed in quotes-------
grep -h '.zip' dirlist*.txt  
bunzip2
bzip2
bzip2recover
gunzip
gzip
gpg-zip
prezip-bin
unzipsfx

Anchors------------------------------
grep -h '^zip' dirlist*.txt  # at the beginning of the line
zip
zipcloak
zipnote
zipsplit

grep -h 'zip$' dirlist*.txt   #at the end of the line
gunzip
gzip
gpg-zip
unzip
zip

grep -h '^zip$' dirlist*.txt   # zip

grep -i '^..j.r$' /usr/share/dict/words
Major
major

Bracket Expressions & Character Classes===================
grep -h '[bg]zip' dirlist*.txt  #or [] == | 
bzip2
gzip

metacharacters lose their special meaning, within brackets. 
caret (^) => negation; dash (-) => a character range

grep -h '[^bg]zip' dirlist*.txt  #negation
bunzip2
gunzip
funzip

grep -h '^[A-Z]' dirlist*.txt  #range
MAKEDEV
HEAD
POST

grep -h '^[A-Za-z0-9]' dirlist*.txt
grep -h '[A-Z]' dirlist*.txt  # dash (-) a character range
grep -h '[-AZ]' dirlist*.txt  # match every filename containing a dash, an uppercase A, or an uppercase Z.
POSIX Character Classes============================
ls /usr/sbin/[A-Z]*  # ls /usr/sbin/[ABCDEFGHIJKLMNOPQRSTUVWXYZ]*
echo $LANG  # en_US.UTF-8

POSIX Character Classes------------------------------------
Character       Class Description
[:alnum:] 	equivalent to [A-Za-z0-9] in ASCII
[:word:] 	same as [:alnum:], with including underscore character (_)
[:alpha:] 	equivalent to [A-Za-z] in ASCII, 
[:cntrl:]	ASCII control codes; includes the ASCII characters 0 through 31 and 127
[:graph:] 	visible characters; in ASCII, includes characters 33 through 126
[:lower:] 	lowercase vs.  [:upper:] 	
[:punct:]	punctuation characters; in ASCII, equivalent to[-!"#$%&'()*+,./:;<=>?@[\\\]_`{|}~] `
[:print:] 	printable characters; all the characters in [:graph:] plus the space character
[:blank:] 	space & tab characters
[:space:]	whitespace characters (space, tab, carriage return, newline, vertical tab, and form feed) ; in ASCII, equivalent to [ \t\r\n\v\f]
[:digit:] 	numerals 0 through 9
[:xdigit:]	Characters used to express hexadecimal numbers; in ASCII, equivalent to [0-9A-Fa-f]
				   
REVERTING TO TRADITIONAL COLLATION ORDER------------------------------------
$ locale
LANG=en_US.UTF-8
LC_CTYPE="en_US.UTF-8"
LC_NUMERIC="en_US.UTF-8"
LC_TIME="en_US.UTF-8"
LC_COLLATE="en_US.UTF-8"
LC_MONETARY="en_US.UTF-8"
LC_MESSAGES="en_US.UTF-8"
LC_PAPER="en_US.UTF-8"
LC_NAME="en_US.UTF-8"
LC_ADDRESS="en_US.UTF-8"
LC_TELEPHONE="en_US.UTF-8"
LC_MEASUREMENT="en_US.UTF-8"
LC_IDENTIFICATION="en_US.UTF-8"
LC_ALL=

$ export LANG=POSIX   # converts the system to use US English (more specifically, ASCII) for its character set, so be sure this is really what you want.
make it permanent => .bashrc , export LANG=POSIX

BRE vs ERE metacharacters=================
With BRE,  recognized: ^ $  [ ] . *    All other characters== literals. 
With ERE,        adds: ( ) { } ? + |

Alternation----------------------
echo "AAA" | grep AAA  # AAA
echo "BBB" | grep AAA  # null
echo "AAA" | egrep 'AAA|BBB'  # AAA
echo "AAA" | egrep 'AAA|BBB|CCC'          regular expression in quotes:  prevent the shell from interpreting the vertical pipe metacharacter as a pipe
AAA
egrep '^(bz|gz|zip)' dirlist*.txt  # match the filenames start with either bz, gz, or zip
egrep '^bz|gz|zip' dirlist*.txt  # filename that begins with bz or contains gz or contains zip.

Quantifiers====================================================
\(?  ===> \ treats ( as literal,   ? matchs ( as 0 or 1 
^\(?[0-9][0-9][0-9]\)? [0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]$  

echo "(555) 123-4567" | egrep '^\(?[0-9][0-9][0-9]\)? [0-9][0-9][0-9]$' # (555) 123-4567
echo "555 123-4567"   | egrep '^\(?[0-9][0-9][0-9]\)? [0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]$' # 555 123-4567
echo "AAA 123-4567"   | egrep '^\(?[0-9][0-9][0-9]\)? [0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]$' # [me@linuxbox ~]$

? 0 or 1 
* 0 or More 
+ 1 or More 
^([[:alpha:]]+ ?)+$  # match only lines consisting of groups of one or more alphabetic characters separated by single spaces

echo "This that" | grep -E '^([[:alpha:]]+ ?)+$'  #This that
echo "a b c" | grep -E '^([[:alpha:]]+ ?)+$'    # a b c
echo "a b 9" | grep -E '^([[:alpha:]]+ ?)+$'    #null
echo "abc d" | grep -E '^([[:alpha:]]+ ?)+$'    # abc d

{} Match, a Specific Number of Times
^\(?[0-9][0-9][0-9]\)? [0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]$ to  ^\(?[0-9]{3}\)? [0-9]{3}-[0-9]{4}$
echo "(555) 123-4567" | egrep '^\(?[0-9]{3}\)? [0-9]{3}-[0-9]{4}$' # (555) 123-4567
echo "555 123-4567" | egrep '^\(?[0-9]{3}\)? [0-9]{3}-[0-9]{4}$'   # 555 123-4567
echo "5555 123-4567" | egrep'^\(?[0-9]{3}\)? [0-9]{3}-[0-9]{4}$'  # null

for i in {1..10}; do echo "(${RANDOM:0:3}) ${RANDOM:0:3}-${RANDOM:0:4}" >> phonelist.txt; done  && cat phonelist.txt
(232) 298-2265
(624) 381-1078
...

egrep -v '^\([0-9]{3}\) [0-9]{3}-[0-9]{4}$' phonelist.txt # inverse match
(292) 108-518
(129) 44-1379

find . -regex '.*[^-_./0-9a-zA-Z].*'  # path name, not a member of [-_./0-9a-zA-Z]

Searching for Files with locate------------
locate --regex 'bin/(bz|gz|zip)'
/bin/bzcat
/bin/bzcmp
/bin/bzdiff
...
Searching for Text with less and vim-------
(232) 298-2265
(624) 381-1078
(540) 126-1980
...
/^\([0-9]{3}\) [0-9]{3}-[0-9]{4}$   # less will highlight the strings that match, leaving the invalid ones easy to spot

*******poisitionParams***********************************

----------------------------
# view command line parameters         $0 : always path name
echo "   
\$0 = $0         
\$1 = $1
...
\$9 = $9
"
--------------------------
${10}, ${55} ... ${211} #  a number greater than nine

shift-Getting Access to Many Arguments==============
#display all arguments
count=1
while [[ $# -gt 0 ]]; do
                echo "Argument $count = $1"
                count=$((count + 1))
                shift  # execute a shift to load $1 with the next argument
done
./simapp.sh================================
PROGNAME=$(basename $0)   #file information program       
if [[ -e $1 ]]; then
                echo -e "\nFile Type:"; file $1
                echo -e "\nFile Status:"; stat $1
else
                echo "$PROGNAME: usage: $PROGNAME file" >&2  # redirect stdout to stderr (file descriptor 2)
                exit 1
fi
------------------------------------------------
<< desc
#@: total num of args 
$#: args   
$*: all args as a single value
$@: all args as a list 
desc

echo "$# args were entered and they are $@ "
echo "$* entered "

echo -e "\n arg1: $1\n arg2: $2\n arg3: $3"
echo -e "\n\n now shifting"

shift
echo -e "\n first shifting to the right"
sleep 1
echo -e "\n arg1: $1\n arg2: $2\n arg3: $3"

shift
echo -e "\n second shifting to the right"
sleep 1
echo -e "\n arg1: $1\n arg2: $2\n arg3: $3"

shift
echo -e "\n third shifting to the right "
sleep 1
echo -e "\n arg1: $1\n arg2: $2\n arg3:$3"

exit
-----------------------------------------------------------
print_param () {  # demonstrate $* and $@
        echo "\$1 = $1 "
        echo "\$2 = $2 "
        echo "\$3 = $3 "
        echo "\$4 = $4 "
}
pass_param () {
        echo -e "\n" ' $* :   '  ; print_param $*    # $* : Expands into the list of positional param,starting with 1
        echo -e "\n" ' $@ :   '  ; print_param $@    # $@ : Expands into the list of positional param, starting with 1	
        echo -e "\n" ' "$*" : '  ; print_param "$*"  # double quoted, separated by IFS shell variable 
        echo -e "\n" ' "$@" : '  ; print_param "$@"  # double quoted, separated by double quotes.
}                                                    # "$@" is most useful , preserves the integrity of each positional parameter.
pass_param "word" "words with spaces"
------------------------------------------------------------------
$* :
$1 = word
$2 = words
$3 = with
$4 = spaces

$@ :
$1 = word
$2 = words
$3 = with
$4 = spaces

"$*" : word words with spaces

"$@" :
$1 = word
$2 = words with spaces
$3 =
$4 =
=====sys_info_page=============================================
PROGRAM=$(basename $0)               
TITLE="System Information Report for $HOSTNAME"
CURRENT_TIME=$(date +"%x %r %Z")
TIME_STAMP="Generated $CURRENT_TIME, by $USER"

report_uptime () {
        cat <<- _EOF_
        System Uptime
        $(uptime)
_EOF_
        return
}

report_disk_space () {
        cat <<- _EOF_ 
        Disk Space Utilization
        $(df -h)
_EOF_
        return
}

report_home_space () {
        if [[ $(id -u) -eq 0 ]]; then
                cat <<-  _EOF_
                        Home Space Utilization (All Users)
                        $(du -sh /home/*)
_EOF_
        else
                cat <<- _EOF_
                        Home Space Utilization ($USER)
                        $(du -sh $HOME)
_EOF_
        fi
return 
}

usage () {
        echo "$PROGNAME: usage: $PROGNAME [-f file | -i]"
        return
}

write_html_page() {
        cat <<- _EOF_
                        $(report_uptime)
                        $(report_disk_space)
                        $(report_home_space)
_EOF_
return
}
-------------------------------------------------------
interactive=      # process command line options
filename=
while [[ -n $1 ]]; do
        case $1 in
                -f | --file) shift
                             filename=$1
                ;;
                -i | --interactive) interactive=1
                ;;
                -h | --help) usage
                             exit
                ;;
                *) usage >&2
                   exit 1
                ;;
        esac
shift
done

if [[ -n $interactive ]]; then  # interactive mode
        while true; do
                read -p "Enter name of output file:" filename
                if [[ -e $filename ]]; then
                        read -p "'$filename' exists. Overwrite? [y/n] > "
                                case $REPLY in
                                        Y|y) break
                                             ;;
                                        Q|q) echo "Program terminated"
                                                exit
                                                ;;
                                        *)      contine
                                                ;;
                                esac
                fi
        done
fi

if [[ -n $filename ]]; then  # output html page
        if touch $filename && [[ -f $filename ]]; then
                write_html_page > $filename ##
        else
                echo "$PROGNAME: Cannot write file '$filename'" >&2
                exit 1
        fi
else
        write_html_page
fi

***************Array********************
Creating an Array=============
a[1]=foo ; echo ${a[1]}     # declare -a a     # foo
days=(Sun Mon Tue Wed Thu Fri Sat) ; days=([0]=Sun [1]=Mon [2]=Tue [3]=Wed [4]=Thu [5]=Fri [6]=Sat)

Accessing Array Elements------------------
# produces a table: for each hour of the day (0–23), the num of last modified files.
usage () {
            echo "usage: $(basename $0) directory" >&2
        }

if [[ ! -d $1 ]]; then
    usage
    exit 1
fi
                               
for i in {0..23}; do hours[i]=0; done  # Initialize array

for i in $(stat -c %y "$1"/* | cut -c 12-13); do   # # Collect data
                j=${i/#0}         # remove leading zeros from the hour field            
                ((++hours[j]))    # increment the value of the array element corresponding with the hour of the day
                ((++count))       # track the total number of files in the directory
done
 
echo -e "Hour\tFiles\tHour\tFiles"  # Display data
echo -e "----\t-----\t----\t-----"
                for i in {0..11}; do
                    j=$((i + 12))
                    printf "%02d\t%d\t%02d\t%d\n" $i ${hours[i]} $j ${hours[j]}   #enter a loop that produces two columns of output
                done
printf "\nTotal files = %d\n" $count

output the entire content of an array===============
animals=("a dog" "a cat" "a fish")
for i in ${animals[*]}; do echo $i; done  # a /n  dog /n a /n cat /n a /n fish
for i in ${animals[@]}; do echo $i; done  # a /n  dog /n a /n cat /n a /n fish

for i in "${animals[*]}"; do echo $i; done   # (single line)  a dog a cat a fish    
for i in "${animals[@]}"; do echo $i; done   # (three seperate lines) a dog /n a cat /n a fish

Number of Array Elements=================
a[100]=foo ; echo ${#a[@]} ; echo ${#a[100]}    # 1  parameter expansion: number of arr elements    # 3  parameter expansion: length of element 100

=index=========================
foo=([2]=a [4]=b [6]=c); for i in "${foo[@]}"; do echo $i; done   #value  # a /n b /n c
for i in "${!foo[@]}"; do echo $i; done  #index  # 2 /n 4 /n 6

Adding Elements to the End of an Array===========
foo=(a b c);  echo ${foo[@]} ; foo+=(d e f); echo ${foo[@]}  # a b c d e f
 
a=(f e d c b a) ; echo "Original array: ${a[@]}"
a_sorted=($(for i in "${a[@]}"; do echo $i; done | sort)) ; echo "Sorted array: ${a_sorted[@]}"
 
Deleting an Array===========================
foo=(a b c d e f); echo ${foo[@]} ; unset foo      ; echo ${foo[@]}  # [me@linuxbox ~]$
foo=(a b c d e f); echo ${foo[@]} ; unset 'foo[2]' ; echo ${foo[@]}  # a b d e f    
foo=(a b c d e f); foo= ; echo ${foo[@]}   # b c d e f

Any reference to an array var without an index == element 0 
foo=(a b c d e f) ; echo ${foo[@]}   # a b c d e f
foo=A ; echo ${foo[@]}               # A b c d e f
 
Arrays and loops have a natural affinity and are often used together.
The following form of loop is  to calculating array subscripts: 
for ((expr1; expr2; expr3))