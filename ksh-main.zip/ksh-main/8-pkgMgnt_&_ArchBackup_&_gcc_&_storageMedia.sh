Package management: a method of installing and maintaining software on the system
dependencies: package management systems all provide some method of dependency resolution.
A package file : a compressed collection of files that contains the sw package ( package_name:  the actual name of a package)

Packaging System 			                    Distributions (partial listing)----
Debian style(.deb) / Red Hat style(.rpm) 		Debian, Ubuntu / Fedora, CentOS, Red Hat Enterprise Linux-RHEL
		
How a Package System Works------
The package maintainer gets the software in source code >> compiles it, >> creates the package metadata & any installation scripts. 
Often, the package maintainer will apply modifications to the original source code
 to improve the program’s integration with the other parts of the Linux distribution.

Repositories-------
 a testing repository: for use by brave souls who are looking for bugs, before the packages are released.
 a development repository:  where work-in-progress packages destined for inclusion in the distribution’s next major release are kept.

Package Tools--------
high-level tools: metadata searching and dependency resolution.  apt-get/yum
low-level tools:  installing and removing package files          dpkg/rpm 				

yum search emacs   :Package Search                                                         apt-get update  			
yum install emacs  :Package Install from a repository with full dependency resolution      apt-get update; apt-get install emacs
rpm -i emacs-22.1-7.fc7-i386.rpm  :Low-Level Pkg Install, from a source other than a repo  dpkg --install package_file
yum erase emacs           :remove a pkg                                                    apt-get remove emacs

yum update			      : Updating Packages from a Repository                        apt-get update; apt-get upgrade
rpm -U package_file       : Upgrading a Package from a Package File                    dpkg --install package_file

rpm -qa                   :  list installed pkgs                                       dpkg --list
rpm -q package_name       : Package Status : installed pkg							   pkg --status package_name

yum info pkg              : Information About an Installed Package	                   apt-cache show package_name
rpm -qf /usr/bin/vim      : Pkg File Identification Cmd: Which pkg Installed a File    dpkg --search file_name

****Archiving and backup************
=gzip:  Compress or expand files.  very fast compression============
ls -l /etc > foo.txt ; ls -l foo.*  # -rw-r--r-- 1 me me 15738 2012-10-14 07:15 foo.txt
gzip foo.txt; ls -l foo.*           # -rw-r--r-- 1 me me 3230 2012-10-14 07:15 foo.txt.gz
gunzip foo.txt ; ls -l foo.*        # -rw-r--r-- 1 me me 15738 2012-10-14 07:15 foo.txt

gzip foo.txt; gzip -tv foo.txt.gz   #-t: Test the integrity of a compressed file. # foo.txt.gz: OK
gzip -d foo.txt.gz  #-d:  Decompress. act like gunzip.

ls -l /etc | gzip > foo.txt.gz; gunzip foo.txt
gunzip -c foo.txt | less  # -c:  Write output to standard output and keep original files.
zcat foo.txt.gz | less    # zcat: equivalent to gunzip with -c option.

=bzip2—Higher Compression , at the Cost of Speed================

ls -l /etc > foo.txt; ls -l foo.txt  # -rw-r--r-- 1 me me 15738 2012-10-17 13:51 foo.txt
bzip2 foo.txt; ls -l foo.txt.bz2     # -rw-r--r-- 1 me me 2792 2012-10-17 13:51 foo.txt.bz2
bunzip2 foo.txt.bz2

gzip picture.jpg
Don’t do it. actually end up with a larger file. because all compression techniques involve some overhead that
is added to the file to describe the compression. If you try to compress a file
that already contains no redundant information, the compression will not result
in any savings to offset the additional overhead.

=tar: Tape-archiving utility.===========
c/x  Create vs extract
r  Append specified pathnames to the end of an archive.
t  List the contents of an archive.
f specify the name of the tar archive

mkdir -p playground/dir-{00{1..9},0{10..99},100} && touch playground/dir-{00{1..9},0{10..99},100}/file-{A..Z}
tar cf playground.tar playground; tar tvf playground.tar
mkdir foo && cd foo ; tar xf ../playground.tar; ls # playground

=extract only files matching the specified pathname-----
cd foo && tar xf ../playground2.tar --wildcards 'home/me/playground/dir-*/file-A'
-------------------------Geoff
$ tar -zxvf appconfig.tar.gz --directory=/etrade/tmp/appconfig/2022.11.01-1/appconfig ./app/*-dev.* --strip-components=2
./app/pcdemoui.app-dev.config
./app/pcdemoui.app-dev.json
$ find
.
./appconfig.tar.gz
./appconfig
./appconfig/pcdemoui.app-dev.config
./appconfig/pcdemoui.app-dev.json
---------------------------------

find playground -name 'file-A' -exec tar rf playground.tar '{}' '+'  #incremental backup
find playground -name 'file-A' | tar cf - --files-from=- | gzip > playground.tgz

mkdir remote-stuff && cd remote-stuff; ssh remote-sys 'tar cf - Documents' | tar xf -
'me@remote-sys's password:
[me@linuxbox remote-stuff]$ ls # Documents

unzip -l playground.zip playground/dir-087/file-Z  #extracted selectively
cd foo  && unzip ../playground.zip playground/dir-087/file-Z  #only specificed path
zip -r playground.zip playground   #only specified path
adding: playground/dir-020/file-Z (stored 0%)
adding: playground/dir-020/file-Y (stored 0%)
adding: playground/dir-020/file-X (stored 0%)
adding: playground/dir-087/ (stored 0%)
adding: playground/dir-087/file-S (stored 0%)

find playground -name "file-A" | zip -@ file-A.zip  #pipe a list of filenames to zip via the -@ option:
ls -l /etc/ | zip ls-etc.zip -   # - waiting for stidin for the stdout on the left of the pipe

===rsync:   Remote file and directory synchronization.===================
rsync -av playground foo  #rsync options source destination

mkdir /media/BigDisk/backup; sudo rsync -av --delete /etc /home /usr/local /media/BigDisk/backup
# --delete option to remove files existed on the backup device that no longer existed on the source device
alias backup='sudo rsync -av --delete /etc /home /usr/local /media/BigDisk/backup'  #create an alias and add it to our .bashrc file to provide this feature:
sudo rsync -av --delete --rsh=ssh /etc /home /usr/local remotesys:/backup # rsync over network: --rsh=ssh : rsync to use the ssh program as its remote shell. 

Mirror a software repo========================
RedHat Software maintains a large repo of software packages  under development for its Fedora distribution.
useful for software testers to mirror this collection during the testing phase of the distribution release cycle. 
mkdir fedora-devel; rsync -av -delete rsync://rsync.gtlib.gatech.edu/fedoralinux-core/development/i386/os fedora-devel  #remote rsync server, a protocol (rsync://)

*****compiling prgm***************  #12/29/22
gcc (GNU C Compiler)
which gcc  # /usr/bin/gcc
mkdir src; cd src

$ ftp ftp.gnu.org # anonymous
ftp> cd gnu/diction
250 Directory successfully changed.
ftp> ls
200 PORT command successful. Consider using PASV.
150 Here comes the directory listing.
-rw-r--r-- 1 1003 65534 68940 Aug 28 1998 diction-0.7.tar.gz
-rw-r--r-- 1 1003 65534 90957 Mar 04 2002 diction-1.02.tar.gz
-rw-r--r-- 1 1003 65534 141062 Sep 17 2007 diction-1.11.tar.gz
ftp> get diction-1.11.tar.gz
ftp> bye
221 Goodbye.

[me@linuxbox src]$ ls
diction-1.11.tar.gz

tar tzvf tarfile | head
$ tar xzf diction-1.11.tar.gz
[me@linuxbox src]$ ls
diction-1.11 diction-1.11.tar.gz

Building the Program: two-command sequence:  ./configure  >>   make -----

configuration file:  instructs make program exactly how to build the program. 
[me@linuxbox diction-1.11]$ less Makefile; rm getopt.o;  make

make insists that targets be newer than their dependencies-----
[me@linuxbox diction-1.11]$ ls -l diction getopt.c
-rwxr-xr-x 1 me me 37164 2009-03-05 06:14 diction
-rw-r--r-- 1 me me 33125 2007-03-30 17:45 getopt.c

[me@linuxbox diction-1.11]$ touch getopt.c;  ls -l diction getopt.c
-rwxr-xr-x 1 me me 37164 2009-03-05 06:14 diction
-rw-r--r-- 1 me me 33125 2009-03-05 06:23 getopt.c

[me@linuxbox diction-1.11]$ make;  ls -l diction getopt.c
-rwxr-xr-x 1 me me 37164 2009-03-05 06:24 diction
-rw-r--r-- 1 me me 33125 2009-03-05 06:23 getopt.c

Install=========
/usr/local/bin, for locally built software. superuser to perform the installation

[me@linuxbox diction-1.11]$ sudo make install; which diction
/usr/local/bin/diction
[me@linuxbox diction-1.11]$ man diction

./configure, make, make install:  build many source code packages. 
make plays in the maintenance of programs (maintain a target/dependency relationship, not just for compiling source code.)

******Storage Media********************
mount:  Mount a filesystem.   vs unmount
fdisk:  Partition table manipulator.
fsck:   Check & repair a filesystem.
fdformat: Format a floppy disk.
mkfs: Create a filesystem.
dd: Write block-oriented data directly to a device.
wodim (cdrecord): Write data to optical storage media.
genisoimage (mkisofs): Create an ISO 9660 image file.
md5sum: Calculate an MD5 checksum.

Mounting and Unmounting Storage Devices========================
/etc/fstab : lists the devices (typically HD partitions),  mounted at boot time.
device  /mountpoint  /fs type /options   /frequency  /order
LABEL=/12 		/ 	  ext3     defaults      1    1
LABEL=/home 	/home ext3     defaults      1    2
LABEL=/boot 	/boot ext3     defaults      1    2

/etc/fstab Fields======================================
Field 			Contents 	Description
1 				Device 		actual name of a device file associated with the physical device,
 							/dev/hda1 (the first partition of the master device on the first IDE channel). 
						    hot pluggable (like USB drives), many modern Linux distributions associate a device with a text label
                            This label (which is added to the storage medium when it is formatted) is read by the os
							when the device is attached to the system. That way, no matter which device file is
							assigned to the actual physical device, it can still be correctly identified.

2 				Mount point The directory where the device is attached to the filesystem tree

3 				Filesystem type  native Linux filesystems are ext3, but many
								others are supported, such as FAT16 (msdos), FAT32(vfat), NTFS (ntfs), CD-ROM (iso9660), etc.

4 				Options         read only or to prevent any programs from being
								executed from them (a useful security feature for removable media).

5 				Frequency 		A single number that specifies if and when a filesystem
								is to be backed up with the dump command

6 				Order		    A single number that specifies in what order filesystems
							    should be checked with the fsck command
								
Viewing a List of Mounted Filesystems===================
$ mount

mount the CD-ROM at the new mount point-----------------
umount /dev/hdc; mkdir /mnt/cdrom;  mount -t iso9660 /dev/hdc /mnt/cdrom
cd /mnt/cdrom; ls; cd ..; umount /dev/hdc 

Determining Device Names=============================
$ ls /dev

Linux Storage Device Names--------------
/dev/fd*				Floppy disk drives
/dev/hd* 				IDE (PATA) disks on older systems. Typical motherboards
						contain two IDE connectors, or channels, each with a cable
						with two attachment points for drives. 
						/dev/hda refers to the master device on the first channel,
						/dev/hdb is the slave device on the first channel;
						/dev/hdc, the master device on the second channel, 
						A trailing digit indicates the partition number on the
						device. For example, /dev/hda1 refers to the first partition
						on the first hard drive on the system while /dev/hda refers to
						the entire drive.

/dev/lp* 				Printers

/dev/sd* 				SCSI disks. On recent Linux systems, the kernel treats all
						disk-like devices including PATA/SATA hard disks, flash
						drives, and USB mass storage devices as SCSI disks. 

/dev/sr*				 Optical drives (CD/DVD readers and burners)
----------------------------------------------
[me@linuxbox ~]$ sudo tail -f /var/log/messages

plug in the removable device, a 16MB flash drive. the kernel will notice the device and probe it:
Jul 23 10:07:59 linuxbox kernel: sdb: sdb1
Jul 23 10:07:59 linuxbox kernel: sd 3:0:0:0: [sdb] Attached SCSI removable disk

$ sudo mkdir /mnt/flash; sudo mount /dev/sdb1 /mnt/flash; df

Creating New Filesystems============================
[me@linuxbox ~]$ sudo umount /dev/sdb1; sudo fdisk /dev/sdb

Command (m for help):
Entering an m will display the program menu:
Command action----
a toggle a bootable flag
b edit bsd disklabel
c toggle the dos compatibility flag
d delete a partition
l list known partition types
m print this menu
n add a new partition
o create a new empty DOS partition table
p print the partition table
q quit without saving changes
s create a new empty Sun disklabel
t change a partition's system id'
u change display/entry units
v verify the partition table
w write table to disk and exit
x extra functionality (experts only)
-------------------------------------

Command (m for help): p           p: print the partition table for the device

Disk /dev/sdb: 16 MB, 16006656 bytes
1 heads, 31 sectors/track, 1008 cylinders
Units = cylinders of 31 * 512 = 15872 bytes

Device Boot Start End Blocks Id System
/dev/sdb1 2 1008 15608+ b W95 FAT32

---------------------------------
Command (m for help): t
Selected partition 1
Hex code (type L to list codes): 83      l: list known partition types
Changed system type of partition 1 to 83 (Linux)
------------------------------------
Command (m for help): w                  w: write table to disk and exit  vs q (exit the program without writing)

The partition table has been altered!
Calling ioctl() to re-read partition table.
WARNING: If you have created or modified any DOS 6.x
partitions, please see the fdisk manual page for additional
information.
Syncing disks.

Creating a New Filesystem with mkfs=======================
[me@linuxbox ~]$ sudo mkfs -t ext3 /dev/sdb1
mke2fs 1.40.2 (12-Jul-2012)
Filesystem label=
OS type: Linux
Block size=1024 (log=0)
Fragment size=1024 (log=0)
3904 inodes, 15608 blocks
780 blocks (5.00%) reserved for the super user
First data block=1
Maximum filesystem blocks=15990784

$ sudo mkfs -t vfat /dev/sdb1

Testing and Repairing Filesystems=========================
[me@linuxbox ~]$ sudo fsck /dev/sdb1
fsck 1.40.8 (13-Mar-2012)
e2fsck 1.40.8 (13-Mar-2012)
/dev/sdb1: clean, 11/3904 files, 1661/15608 blocks

Moving Data Directly to and from Devices=================
dd if=/dev/sdb of=/dev/sdc            dd if=input_file ,  of=output_file [bs=block_size [count=blocks]] , copy everything on the first drive to the second drive:
dd if=/dev/sdb of=flash_drive.img     copy its contents to an ordinary file 

Creating CD-ROM Images==================================
dd if=/dev/cdrom of=ubuntu.iso

Creating an Image from a Collection of Files===========
genisoimage -o cd-rom.iso -R -J ~/cd-rom-files

-R option:  adds metadata for the Rock Ridge extensions, which allow the use of long filenames and POSIX-style file permissions. 
-J option:  enables the Joliet extensions, which permit long filenames in Windows.


Writing CD-ROM Images=======================
-t iso9660 filesystem type  (required)
-o loop option: to mount 

mkdir /mnt/iso_image
mount -t iso9660 -o loop image.iso /mnt/iso_image      : mount the image file (as though it were a device and attach it to the filesystem tree)

wodim dev=/dev/cdrw blank=fast  :Blanking a Rewritable CD-ROM
wodim dev=/dev/cdrw image.iso   :write an image

md5sum image.iso
34e354760f9bb7fbf85c96f6a3f94ece image.iso

