
*********Shell***************
Terminal Emulator: gives access to the shell.

$ date
Thu Oct 25 13:51:54 EDT 2012
$ cal
October 2012
Su Mo Tu We Th Fr Sa
1 2 3 4 5 6
7 8 9 10 11 12 13
14 15 16 17 18 19 20

Navgation================
pwd:  current working directory.
cd:   Change directory.
ls:    List directory contents.
cd :   to your home directory.
cd -  :to the previous working directory.
cd ~username :  to the home directory of username. 

**********commands******************
/usr/bin : executable program (compiled binaries, C and C++ ), or scripting languages (shell, Perl, Python, Ruby)
shell builtin cmd:  (i.e. cd, cmd)
shell function: shell scripts incorporated into the environment. 
alias : Create an alias for a command.
------------------------------------
type — Indicate how a command name is interpreted.
$ type type # type is a shell builtin
$ type ls   # ls is aliased to ls --color=tty
$ type cp   # cp is /bin/cp

which - Display an Executable’s Location, (executable programs, not builtins or aliases)
$ which ls # /bin/ls

Command’s Documentation==================
$ help cd
cd: cd [-L|-P] [dir]

--help : Display Usage Information-----
$ mkdir --help
Usage: mkdir [OPTION] DIRECTORY...

man :Display a Program’s Manual Page----
$ man ls

apropos — Display Appropriate Commands----------
$ apropos floppy  : search for man pages using the search term floppy
create_floppy_devices (8) - udev callout to create all possible
floppy device based on the CMOS type
fdformat (8) - Low-level formats a floppy disk
floppy (8) - format floppy disks

whatis — Display a Very Brief Description of a Command
$ whatis ls
ls (1) - list directory contents

Creating your own commandsd with alias
command1; command2; command3....

$ cd /usr; ls; cd -
bin games kerberos lib64 local share tmp
etc include lib libexec sbin src
/home/me

$ alias foo='cd /usr; ls; cd -'
$ foo
bin games kerberos lib64 local share tmp

$ type foo               # foo is aliased to `cd /usr; ls ; cd -`
$ unalias foo; type foo  # bash: type: foo: not found

$ alias # They vanish when your shell session ends
alias l.='ls -d .* --color=tty'
alias ll='ls -l --color=tty'
alias ls='ls --color=tty'

*********Prompt******************************************
Anatomy of a Prompt===========
echo $PS1
ps1_old="$PS1"  &&  echo $ps1_old ; PS1="\A \h \$ "  # 17:33 linuxbox $
$ PS1="$ps1_old"

Escape Codes Used in Shell Prompts===================
\a ASCII bell. computer beep when it is encountered.
\d Current date in day, month, date format; “Mon May 26”
\h Hostname of the local machine minus the trailing domain name
\H Full hostname
\j Number of jobs running in the current shell session
\l Name of the current terminal device
\n A newline character
\r A carriage return
\s Name of the shell program
\t Current time in 24-hour, hours:minutes:seconds format
\T Current time in 12-hour format
\@ Current time in 12-hour, AM/PM format
\A Current time in 24-hour, hours:minutes format
\u Username of the current user
\v Version number of the shell
\V Version and release numbers of the shell
\w Name of the current working directory
\W Last part of the current working directory name
\! History number of the current command
\# Number of commands entered during this shell session
\$ This displays a “$” character unless you have superuser privileges. In that case, it displays a “#” instead.
\[ This signals the start of a series of one or more non-printing
characters. It is used to embed non-printing control characters
that manipulate the terminal emulator in some way, such as
moving the cursor or changing text colors.
\] This signals the end of a non-printing character sequence.

**system Exploration**********
ls option===================================
-a  (hidden)  -d directories  -h human readable  -l results in a long format  -r  reverse order  -S by file size   -t modification time
$ ls -ltrahS
total 28K #size,
-rw-rw-r--. 1  							ec2-user  ec2-user   7 Aug 31 09:40 		 txt2
           #1: File num of hard link,   user:group ,  		 last modification time, filename
$ less /etc/passwd
less opt 		Action
G 				Move to the end of the text file.
1G   	 		Move to the beginning of the text file.
/characters 	Search forward to the next occurrence of characters.
n 				Search for the next occurrence of the previous search.
h 				Display help screen.
q 				Quit less.

Directories Found on Linux Systems======================
/ 		The root directory
/bin 	binaries  - system to boot and run.	
/boot 	Linux kernel, initial RAM disk image and the boot loader.	
/dev	device nodes. “Everything is a file”.  kernel maintains a list of all the devices it understands.
/etc   all system-wide config files and system service scripts at boot time.
		/etc/crontab,  when automated jobs will run
		/etc/fstab,    a table of storage devices with  associated mount points
		/etc/passwd,    user accounts.

/home		user home, protects the system from errant user activity.
/lib		used by the core system programs, similiar to DLLs.
/lost+found  in the case of a partial recovery from a filesystem corruption event.  	 
/media 		 mount points for removable media -  USB drives, CD-ROMs,etc. mounted automatically at insertion.		
/mnt 		 mount points for removable devices  mounted manually.
/opt 		commercial software 
/proc    	virtual fs maintained by the Linux kernel, peepholes into the kernel itself. how the kernel sees your computer.
/root    	home directory for the root 
/sbin 		“system” binaries. vital system tasks reserved for the superuser.		
/tmp 		 storage of temporary, transient files 
/usr 		 all the programs and files used by regular users.		
/usr/bin 	 executable programs installed by your Linux distribution. 
/usr/lib 	 shared libraries for /usr/bin programs
/usr/local 	 Programs compiled from source code, installed in /usr/local/bin.
/usr/share 	 shared data used by /usr/bin.  default configuration files, icons, screen backgrounds, sound files, etc.										
/var 		 Various databases, spool files, user mail, etc. are located here.			
/var/log 	 /var/log contains log files, various system activity.  very important and should be monitored.
			 /var/log/messages :  for security reasons on some systems, superuser to view log files.
				
***********Manipulating Files and Directories*******************
cp options================================
-a, --archive 		 Copy files and directories and all default attributes, ownerships and permissions of user		
-i, --interactive	 prompt confirmation.
-r, --recursive 	 Recursively copy directories and their contents. 
-u, --update 		 copy only files that either don’t exist or are newer than the existing files in the target irectory.				
-v, --verbose 		 informative messages

cp file1 file2 				Copy file1 to file2. If file2 exists, overwritten with the contents of file1. 
cp -i file1 file2 			if file2 exists, the user is prompted before it is overwritten.							
cp file1 file2 dir1 		Copy file1 and file2 into directory dir1. dir1 must already exist.						
cp dir1/* dir2 				all the files in dir1 are copied into dir2. 			
cp -r dir1 dir2 			Copy directory dir1 (and its contents) to directory dir2. 

$ cp -i /etc/passwd .  # cp: overwrite './passwd'?

mv Examples======================================
mv file1 file2 				Move file1 to file2. If file2 exists, overwritten with the contents of file1.  In either case, file1 ceases to exist.	
mv -i file1 file2 			if file2 exists, the user is prompted before it is overwritten.						
mv file1 file2 dir1 		Move file1 and file2 into directory dir1. dir1 must already exist.			
mv dir1 dir2 				Move directory dir1 (and its contents) into directory dir2. If directory dir2 does not exist, create directory
							dir2, move the contents of directory dir1 into dir2, and delete directory dir1  (rename dir1 to dir2)

Symbolic links vs hard links=====================
lrwxrwxrwx 1 root root 11 2012-08-11 07:34 libc.so.6 -> libc-2.6.so
https://www.cbtnuggets.com/blog/certifications/open-source/linux-hard-links-versus-soft-links-explained
							

ln fun fun-hard; ls -li   # hard link:  ln file link
12353538 -rw-r--r-- 4 me me 1650 2012-01-10 16:33 fun
12353538 -rw-r--r-- 4 me me 1650 2012-01-10 16:33 fun-hard

ln -s dir1 dir1-sym; ls -l  #symbolic link:  ln -s item link
drwxrwxr-x 2 me me 4096 2012-01-15 15:17 dir1
lrwxrwxrwx 1 me me 4    2012-01-16 14:45 dir1-sym -> dir1

